<?php
require_once 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname   = trim($_POST['fname'] ?? '');
    $lname   = trim($_POST['lname'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $pass    = $_POST['password'] ?? '';
    $phone   = trim($_POST['phone'] ?? null);
    $terms   = isset($_POST['terms']) ? 1 : 0;

    if (empty($fname) || empty($lname) || empty($email) || empty($pass) || !$terms) {
        die("Por favor completa todos los campos obligatorios.");
    }

    // Hashear contraseña
    $password_hash = password_hash($pass, PASSWORD_BCRYPT);

    try {
        $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, apellido, email, password_hash, telefono, terminos_aceptados) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$fname, $lname, $email, $password_hash, $phone, $terms]);

        header("Location: index.php?view=login&registered=1");
        exit;
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Error de duplicado
            die("El correo electrónico ya está registrado.");
        }
        die("Error al registrar el usuario: " . $e->getMessage());
    }
}