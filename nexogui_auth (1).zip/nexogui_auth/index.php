<?php
// Configuración básica o procesamiento de formularios si se envía por POST
$view = $_GET['view'] ?? 'login'; // login | register | forgot
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexoGÜI - Conectamos tu comunidad con soluciones</title>
    <!-- Lucide Icons para tipografía de íconos vectoriales -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<div class="auth-container">
    <!-- Panel Izquierdo (Branding & Fondo de Guichón) -->
    <div class="brand-panel">
        <div class="brand-overlay"></div>
        <div class="brand-content">
            <div class="logo-wrapper">
                <div class="logo-icon">
                    <span>N</span>
                </div>
                <h1 class="logo-text">Nexo<span>GÜI</span></h1>
            </div>

            <h2 class="brand-tagline">Conectamos tu comunidad con soluciones.</h2>
            <p class="brand-description">Reportá problemas, participá y ayudá a construir un mejor Guichón.</p>

            <!-- Card informativo dinámico según la vista -->
            <div class="info-card">
                <?php if ($view === 'register'): ?>
                    <div class="info-card-icon">
                        <i data-lucide="users"></i>
                    </div>
                    <div>
                        <h4>Comunidad activa</h4>
                        <p>Sumate a cientos de vecinos que ya están haciendo de Guichón un lugar mejor.</p>
                    </div>
                <?php elseif ($view === 'forgot'): ?>
                    <div class="info-card-icon">
                        <i data-lucide="lock"></i>
                    </div>
                    <div>
                        <h4>Tu seguridad es importante</h4>
                        <p>Te ayudamos a recuperar el acceso a tu cuenta de forma segura.</p>
                    </div>
                <?php else: ?>
                    <div class="info-card-icon">
                        <i data-lucide="shield-check"></i>
                    </div>
                    <div>
                        <h4>Plataforma segura</h4>
                        <p>Tus datos están protegidos con los más altos estándares de seguridad.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Panel Derecho (Formularios) -->
    <div class="form-panel">
        <div class="card-container">

            <!-- VISTA: INICIAR SESIÓN -->
            <?php if ($view === 'login'): ?>
                <div class="form-header">
                    <div class="avatar-icon">
                        <i data-lucide="user"></i>
                    </div>
                    <h2>Iniciar sesión</h2>
                    <p>Ingresá tus credenciales para continuar</p>
                </div>

                <form action="process_login.php" method="POST" class="auth-form">
                    <div class="form-group">
                        <label for="email">Correo electrónico</label>
                        <div class="input-wrapper">
                            <i data-lucide="mail" class="input-icon"></i>
                            <input type="email" id="email" name="email" placeholder="ejemplo@correo.com" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <div class="input-wrapper">
                            <i data-lucide="lock" class="input-icon"></i>
                            <input type="password" id="password" name="password" placeholder="Tu contraseña" required>
                            <i data-lucide="eye" class="toggle-password" onclick="togglePasswordVisibility('password')"></i>
                        </div>
                    </div>

                    <div class="form-options">
                        <label class="checkbox-container">
                            <input type="checkbox" name="remember">
                            <span class="checkmark"></span>
                            Recordarme
                        </label>
                        <a href="?view=forgot" class="link-blue">¿Olvidaste tu contraseña?</a>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i data-lucide="lock"></i> Iniciar sesión
                    </button>
                </form>

                <div class="divider">
                    <span>o continuá con</span>
                </div>

                <div class="social-buttons vertical">
                    <button class="btn btn-social">
                        <svg class="social-logo" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/></svg>
                        Continuar con Google
                    </button>
                    <button class="btn btn-social">
                        <svg class="social-logo" viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                        Continuar con Facebook
                    </button>
                </div>

                <div class="form-footer">
                    ¿No tenés cuenta? <a href="?view=register" class="link-blue font-semibold">Registrate aquí</a>
                </div>

            <!-- VISTA: CREAR CUENTA -->
            <?php elseif ($view === 'register'): ?>
                <div class="form-header">
                    <div class="avatar-icon">
                        <i data-lucide="user-plus"></i>
                    </div>
                    <h2>Crear cuenta</h2>
                    <p>Registrate para comenzar a usar NexoGÜI</p>
                </div>

                <form action="process_register.php" method="POST" class="auth-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="fname">Nombre</label>
                            <div class="input-wrapper">
                                <i data-lucide="user" class="input-icon"></i>
                                <input type="text" id="fname" name="fname" placeholder="Tu nombre" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="lname">Apellido</label>
                            <div class="input-wrapper">
                                <i data-lucide="user" class="input-icon"></i>
                                <input type="text" id="lname" name="lname" placeholder="Tu apellido" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email">Correo electrónico</label>
                        <div class="input-wrapper">
                            <i data-lucide="mail" class="input-icon"></i>
                            <input type="email" id="email" name="email" placeholder="ejemplo@correo.com" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <div class="input-wrapper">
                            <i data-lucide="lock" class="input-icon"></i>
                            <input type="password" id="password" name="password" placeholder="Crea una contraseña" required>
                            <i data-lucide="eye" class="toggle-password" onclick="togglePasswordVisibility('password')"></i>
                        </div>
                        <span class="input-help">Mínimo 8 caracteres, con mayúsculas, minúsculas y números.</span>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Confirmar contraseña</label>
                        <div class="input-wrapper">
                            <i data-lucide="lock" class="input-icon"></i>
                            <input type="password" id="confirm_password" name="confirm_password" placeholder="Repite tu contraseña" required>
                            <i data-lucide="eye" class="toggle-password" onclick="togglePasswordVisibility('confirm_password')"></i>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="phone">Teléfono <span class="optional">(opcional)</span></label>
                        <div class="input-wrapper">
                            <i data-lucide="smartphone" class="input-icon"></i>
                            <input type="tel" id="phone" name="phone" placeholder="098 765 432">
                        </div>
                    </div>

                    <div class="form-options">
                        <label class="checkbox-container">
                            <input type="checkbox" name="terms" required>
                            <span class="checkmark"></span>
                            Acepto los <a href="#" class="link-blue">términos y condiciones</a> y la <a href="#" class="link-blue">política de privacidad</a>
                        </label>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i data-lucide="user-plus"></i> Crear cuenta
                    </button>
                </form>

                <div class="divider">
                    <span>o registrate con</span>
                </div>

                <div class="social-buttons horizontal">
                    <button class="btn btn-social">
                        <svg class="social-logo" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/></svg>
                        Google
                    </button>
                    <button class="btn btn-social">
                        <svg class="social-logo" viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                        Facebook
                    </button>
                </div>

                <div class="form-footer">
                    ¿Ya tenés cuenta? <a href="?view=login" class="link-blue font-semibold">Iniciá sesión</a>
                </div>

            <!-- VISTA: RECUPERAR CONTRASEÑA -->
            <?php elseif ($view === 'forgot'): ?>
                <div class="form-header">
                    <div class="avatar-icon">
                        <i data-lucide="lock"></i>
                    </div>
                    <h2>¿Olvidaste tu contraseña?</h2>
                    <p>No te preocupes, te ayudaremos a recuperarla.</p>
                </div>

                <form action="process_forgot.php" method="POST" class="auth-form">
                    <div class="form-group">
                        <label for="email">Ingresá tu correo electrónico</label>
                        <p class="field-desc">Te enviaremos un enlace para restablecer tu contraseña.</p>
                        <div class="input-wrapper">
                            <i data-lucide="mail" class="input-icon"></i>
                            <input type="email" id="email" name="email" placeholder="ejemplo@correo.com" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i data-lucide="mail"></i> Enviar enlace de recuperación
                    </button>
                </form>

                <div class="alert-box alert-info">
                    <i data-lucide="info" class="alert-icon"></i>
                    <div>
                        <strong>Revisá tu bandeja de entrada</strong>
                        <p>El enlace puede tardar unos minutos en llegar. No olvides revisar tu carpeta de spam.</p>
                    </div>
                </div>

                <div class="divider">
                    <span>o volvé al inicio</span>
                </div>

                <div class="form-footer centered">
                    <a href="?view=login" class="link-blue font-semibold flex-center">
                        <i data-lucide="arrow-left" class="icon-left"></i> Volver al inicio de sesión
                    </a>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<script>
    lucide.createIcons();
</script>
<script src="js/script.js"></script>
</body>
</html>