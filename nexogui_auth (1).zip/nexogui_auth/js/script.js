// Alternar visibilidad de contraseña
function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    const icon = input.nextElementSibling;

    if (input.type === 'password') {
        input.type = 'text';
        icon.setAttribute('data-lucide', 'eye-off');
    } else {
        input.type = 'password';
        icon.setAttribute('data-lucide', 'eye');
    }
    
    // Re-renderizar el ícono de Lucide
    lucide.createIcons();
}

// Validación básica de confirmación de contraseña en el registro
document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.querySelector('form[action="process_register.php"]');
    
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            const pass = document.getElementById('password').value;
            const confirmPass = document.getElementById('confirm_password').value;

            if (pass !== confirmPass) {
                e.preventDefault();
                alert('Las contraseñas no coinciden. Por favor, verificalas.');
            }
        });
    }
});