document.addEventListener('DOMContentLoaded', () => {

    // 1. INICIALIZAR MAPA INTERACTIVO (Centrado en Guichón, Uruguay)
    const guichonCoords = [-32.3486, -57.2000];
    const map = L.map('map').setView(guichonCoords, 14);

    // Cargar mapa
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // Marcador por defecto
    let marker = L.marker(guichonCoords, { draggable: true }).addTo(map);
    marker.bindPopup("<b>Ubicación seleccionada</b><br>Mueve el marcador al punto exacto.").openPopup();

    // Eventos del marcador
    marker.on('dragend', function () {
        const lat = marker.getLatLng().lat;
        const lng = marker.getLatLng().lng;
        
        document.getElementById('latitud').value = lat;
        document.getElementById('longitud').value = lng;
        document.getElementById('ubicacion').value = `Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)}`;
    });

    map.on('click', function(e) {
        marker.setLatLng(e.latlng);
        document.getElementById('latitud').value = e.latlng.lat;
        document.getElementById('longitud').value = e.latlng.lng;
        document.getElementById('ubicacion').value = `Lat: ${e.latlng.lat.toFixed(4)}, Lng: ${e.latlng.lng.toFixed(4)}`;
    });

    // 2. CAMBIO DE CATEGORÍA
    const catButtons = document.querySelectorAll('.cat-btn');
    const selectedCatInput = document.getElementById('selected-category');

    catButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            catButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedCatInput.value = btn.dataset.cat;
        });
    });

    // 3. SELECCIÓN DE FOTO
    const fotoInput = document.getElementById('foto-input');
    const photoLabel = document.getElementById('photo-label');

    fotoInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            photoLabel.textContent = e.target.files[0].name;
        } else {
            photoLabel.textContent = "Subir Foto";
        }
    });
});