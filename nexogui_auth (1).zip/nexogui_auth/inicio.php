<?php
session_start();

// Simulación de usuario en sesión
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_name'] = 'Juan';
    $_SESSION['user_role'] = 'Vecino';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexoGÜI - Inicio</title>
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- Leaflet CSS (Mapa Interactivo OpenStreetMap) -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="css/inicio.css">
</head>
<body>

<div class="dashboard-layout">
    
    <!-- BARRA LATERAL (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon"><span>N</span></div>
            <h1 class="logo-text">Nexo<span>GÜI</span></h1>
        </div>

        <nav class="sidebar-nav">
            <a href="inicio.php" class="nav-item active">
                <i data-lucide="home"></i> Inicio
            </a>
            <a href="#reportar" class="nav-item">
                <i data-lucide="plus-circle"></i> Reportar
            </a>
            <a href="foro.php" class="nav-item">
                <i data-lucide="message-square"></i> Foro
            </a>
            <a href="ajustes.php" class="nav-item">
                <i data-lucide="settings"></i> Ajustes
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="avatar">
                    <i data-lucide="user"></i>
                </div>
                <div class="user-info">
                    <span class="user-name"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Usuario'); ?></span>
                    <span class="user-role"><?php echo htmlspecialchars($_SESSION['user_role'] ?? 'Vecino'); ?></span>
                </div>
                <i data-lucide="chevron-down" class="dropdown-icon"></i>
            </div>
        </div>
    </aside>

    <!-- CONTENIDO PRINCIPAL -->
    <main class="main-content">
        
        <!-- COLUMNA IZQUIERDA / CENTRAL -->
        <div class="content-left">
            
            <header class="page-header">
                <i data-lucide="bar-chart-2" class="header-icon"></i>
                <h2>DASHBOARD PRINCIPAL</h2>
            </header>

            <!-- METRICAS / STATS -->
            <section class="stats-grid">
                <div class="stat-card blue">
                    <div class="stat-icon"><i data-lucide="file-text"></i></div>
                    <div class="stat-data">
                        <span class="stat-number">1,247</span>
                        <span class="stat-label">Reportes</span>
                    </div>
                </div>

                <div class="stat-card green">
                    <div class="stat-icon"><i data-lucide="check-circle"></i></div>
                    <div class="stat-data">
                        <span class="stat-number">892</span>
                        <span class="stat-label">Resueltos</span>
                    </div>
                </div>

                <div class="stat-card purple">
                    <div class="stat-icon"><i data-lucide="clock"></i></div>
                    <div class="stat-data">
                        <span class="stat-number">3.2</span>
                        <span class="stat-label">días Promedio</span>
                    </div>
                </div>
            </section>

            <!-- FORMULARIO NUEVO REPORTE -->
            <section class="card-section" id="reportar">
                <div class="section-header">
                    <i data-lucide="mega-phone" class="section-icon"></i>
                    <h3>NUEVO REPORTE</h3>
                </div>

                <form action="process_report.php" method="POST" enctype="multipart/form-data" class="report-form">
                    
                    <!-- Categorías -->
                    <div class="form-row">
                        <label class="row-label">Categoría:</label>
                        <div class="category-group">
                            <button type="button" class="cat-btn active" data-cat="Vías">
                                <i data-lucide="milestone"></i> Vías
                            </button>
                            <button type="button" class="cat-btn" data-cat="Alumbrado">
                                <i data-lucide="lightbulb"></i> Alumbrado
                            </button>
                            <button type="button" class="cat-btn" data-cat="Parques">
                                <i data-lucide="trees"></i> Parques
                            </button>
                            <button type="button" class="cat-btn" data-cat="Agua">
                                <i data-lucide="droplet"></i> Agua
                            </button>
                        </div>
                        <input type="hidden" name="categoria" id="selected-category" value="Vías">
                    </div>

                    <!-- Ubicación -->
                    <div class="form-row">
                        <label class="row-label" for="ubicacion">Ubicación:</label>
                        <div class="input-with-icon">
                            <input type="text" id="ubicacion" name="ubicacion" placeholder="Buscar dirección o seleccionar en el mapa..." required>
                            <i data-lucide="map-pin" class="input-icon"></i>
                        </div>
                        <input type="hidden" id="latitud" name="latitud">
                        <input type="hidden" id="longitud" name="longitud">
                    </div>

                    <!-- Descripción -->
                    <div class="form-row flex-column">
                        <label class="row-label" for="descripcion">Descripción:</label>
                        <textarea id="descripcion" name="descripcion" rows="4" placeholder="Describe el problema en detalle..." required></textarea>
                    </div>

                    <!-- Botones de Acción -->
                    <div class="form-actions">
                        <label class="btn btn-outline">
                            <i data-lucide="upload"></i> <span id="photo-label">Subir Foto</span>
                            <input type="file" name="foto" id="foto-input" accept="image/*" hidden>
                        </label>

                        <button type="submit" class="btn btn-primary">
                            <i data-lucide="send"></i> ENVIAR REPORTE
                        </button>
                    </div>

                </form>
            </section>

        </div>

        <!-- COLUMNA DERECHA / MAPA & EMERGENCIAS -->
        <div class="content-right">
            
            <div class="map-card">
                <div class="map-header">
                    <i data-lucide="map-pin" class="map-icon"></i>
                    <h3>MAPA INTERACTIVO DE GUICHÓN</h3>
                </div>
                <div id="map"></div>
            </div>

            <!-- Widget Emergencias -->
            <div class="contact-card emergency">
                <div class="card-icon-round red">
                    <i data-lucide="siren"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-title"><i data-lucide="siren" class="inline-icon"></i> Emergencias:</span>
                    <span class="contact-number red-text">911</span>
                </div>
            </div>

            <!-- Widget Municipio -->
            <div class="contact-card municipio">
                <div class="card-icon-round blue">
                    <i data-lucide="landmark"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-title"><i data-lucide="landmark" class="inline-icon"></i> Municipio:</span>
                    <span class="contact-number blue-text">2200</span>
                </div>
            </div>

        </div>

    </main>

</div>

<!-- Scripts -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    lucide.createIcons();
</script>
<script src="js/inicio.js"></script>
</body>
</html>