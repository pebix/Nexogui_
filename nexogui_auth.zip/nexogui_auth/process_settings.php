<?php
session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?view=login");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ajustes.php");
    exit;
}

$usuario_id     = $_SESSION['user_id'];
$nombreCompleto = trim($_POST['nombre'] ?? '');
$email          = trim($_POST['email'] ?? '');
$telefono       = trim($_POST['telefono'] ?? '');
$direccion      = trim($_POST['direccion'] ?? '');
$biografia      = trim($_POST['biografia'] ?? '');

if (empty($nombreCompleto) || empty($email)) {
    die("El nombre y el correo son obligatorios.");
}

// Separar "Nombre Apellido" en dos columnas (nombre = primera palabra, apellido = el resto)
$partes   = explode(' ', $nombreCompleto, 2);
$nombre   = $partes[0];
$apellido = $partes[1] ?? '';

try {
    $stmt = $pdo->prepare("UPDATE usuarios 
                            SET nombre = ?, apellido = ?, email = ?, telefono = ?, direccion = ?, biografia = ?
                            WHERE id = ?");
    $stmt->execute([$nombre, $apellido, $email, $telefono, $direccion, $biografia, $usuario_id]);

    // Actualizar también los datos guardados en la sesión, para que el sidebar
    // muestre el nombre nuevo sin tener que volver a loguearse
    $_SESSION['user_name'] = $nombre . ' ' . $apellido;

    header("Location: ajustes.php?guardado=1");
    exit;

} catch (PDOException $e) {
    if ($e->getCode() == 23000) {
        die("Ese correo electrónico ya está en uso por otra cuenta.");
    }
    die("Error al guardar los cambios: " . $e->getMessage());
}