<?php
session_start();
require_once 'config/db.php';

// 1. Verificar que el usuario esté logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?view=login&error=debes_iniciar_sesion");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: inicio.php");
    exit;
}

// 2. Recoger y validar datos del formulario
$usuario_id  = $_SESSION['user_id'];
$categoria   = trim($_POST['categoria'] ?? '');
$ubicacion   = trim($_POST['ubicacion'] ?? '');
$latitud     = $_POST['latitud'] !== '' ? $_POST['latitud'] : null;
$longitud    = $_POST['longitud'] !== '' ? $_POST['longitud'] : null;
$descripcion = trim($_POST['descripcion'] ?? '');

if (empty($categoria) || empty($ubicacion) || empty($descripcion)) {
    die("Por favor completá todos los campos obligatorios.");
}

// 3. Manejo de la foto (soporta 'foto' único o 'fotos[]' múltiples; guardamos la primera)
$fotoGuardada = null;
$carpetaDestino = 'uploads/reportes/';

if (!is_dir($carpetaDestino)) {
    mkdir($carpetaDestino, 0755, true);
}

// Caso 1: inicio.php envía "foto" (un solo archivo)
if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    $fotoGuardada = guardarImagen($_FILES['foto'], $carpetaDestino);
}

// Caso 2: reportar.php envía "fotos[]" (varios archivos, guardamos la primera)
if (!$fotoGuardada && isset($_FILES['fotos']) && !empty($_FILES['fotos']['name'][0])) {
    $primeraFoto = [
        'name'     => $_FILES['fotos']['name'][0],
        'type'     => $_FILES['fotos']['type'][0],
        'tmp_name' => $_FILES['fotos']['tmp_name'][0],
        'error'    => $_FILES['fotos']['error'][0],
        'size'     => $_FILES['fotos']['size'][0],
    ];
    if ($primeraFoto['error'] === UPLOAD_ERR_OK) {
        $fotoGuardada = guardarImagen($primeraFoto, $carpetaDestino);
    }
}

// 4. Guardar en la base de datos
try {
    $stmt = $pdo->prepare("INSERT INTO reportes (usuario_id, categoria, ubicacion, latitud, longitud, descripcion, foto) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$usuario_id, $categoria, $ubicacion, $latitud, $longitud, $descripcion, $fotoGuardada]);

    header("Location: inicio.php?reporte=exito");
    exit;

} catch (PDOException $e) {
    die("Error al guardar el reporte: " . $e->getMessage());
}

// ------------------------------------------------------
// Función auxiliar: valida y guarda una imagen subida
// ------------------------------------------------------
function guardarImagen(array $archivo, string $carpetaDestino): ?string
{
    $extensionesPermitidas = ['jpg', 'jpeg', 'png'];
    $tamanoMaximo = 5 * 1024 * 1024; // 5MB

    $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));

    if (!in_array($extension, $extensionesPermitidas)) {
        return null; // tipo de archivo no permitido, se ignora
    }

    if ($archivo['size'] > $tamanoMaximo) {
        return null; // demasiado grande, se ignora
    }

    $nombreUnico = uniqid('reporte_', true) . '.' . $extension;
    $rutaCompleta = $carpetaDestino . $nombreUnico;

    if (move_uploaded_file($archivo['tmp_name'], $rutaCompleta)) {
        return $rutaCompleta;
    }

    return null;
}
