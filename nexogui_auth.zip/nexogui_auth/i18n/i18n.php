<?php
// Idiomas soportados
$idiomasDisponibles = ['es', 'en', 'pt'];

// Prioridad: 1) idioma elegido en esta sesión, 2) idioma guardado en el perfil del usuario, 3) español por defecto
$idiomaActual = $_SESSION['idioma'] ?? ($usuario['idioma'] ?? 'es');

if (!in_array($idiomaActual, $idiomasDisponibles)) {
    $idiomaActual = 'es';
}

$GLOBALS['idiomaActual'] = $idiomaActual;
$GLOBALS['lang'] = require __DIR__ . '/lang/' . $idiomaActual . '.php';

// Función de traducción: t('clave') devuelve el texto en el idioma actual
function t($clave) {
    return $GLOBALS['lang'][$clave] ?? $clave;
}