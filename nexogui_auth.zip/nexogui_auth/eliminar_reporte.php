<?php
// Evita que un warning/notice de PHP ensucie la respuesta JSON
error_reporting(E_ALL);
ini_set('display_errors', '0');
ob_start();

session_start();
require_once 'config/db.php';

header('Content-Type: application/json');

// 1. Verificar sesión
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    ob_end_clean();
    echo json_encode(['ok' => false, 'error' => 'Debés iniciar sesión.']);
    exit;
}

// 2. Solo aceptar POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    ob_end_clean();
    echo json_encode(['ok' => false, 'error' => 'Método no permitido.']);
    exit;
}

// 3. Leer el id del reporte enviado como JSON
$datos = json_decode(file_get_contents('php://input'), true);
$reporteId = isset($datos['id']) ? (int) $datos['id'] : 0;

if ($reporteId <= 0) {
    http_response_code(400);
    ob_end_clean();
    echo json_encode(['ok' => false, 'error' => 'ID de reporte inválido.']);
    exit;
}

$usuarioId = $_SESSION['user_id'];

try {
    // 4. Verificar que el reporte exista Y le pertenezca al usuario logueado
    //    (nunca confiar en el id que manda el navegador sin este chequeo)
    $stmt = $pdo->prepare("SELECT foto FROM reportes WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$reporteId, $usuarioId]);
    $reporte = $stmt->fetch();

    if (!$reporte) {
        http_response_code(404);
        ob_end_clean();
        echo json_encode(['ok' => false, 'error' => 'El reporte no existe o no te pertenece.']);
        exit;
    }

    // 5. Borrar el registro de la base de datos
    $stmtBorrar = $pdo->prepare("DELETE FROM reportes WHERE id = ? AND usuario_id = ?");
    $stmtBorrar->execute([$reporteId, $usuarioId]);

    // 6. Borrar la foto asociada del disco, si existe
    if (!empty($reporte['foto']) && file_exists($reporte['foto'])) {
        unlink($reporte['foto']);
    }

    ob_end_clean();
    echo json_encode(['ok' => true]);

} catch (PDOException $e) {
    http_response_code(500);
    ob_end_clean();
    echo json_encode(['ok' => false, 'error' => 'Error al eliminar el reporte: ' . $e->getMessage()]);
}