document.addEventListener("DOMContentLoaded", () => {
    // 1. Inicializar Mapa de Guichón
    const guichonCoords = [-32.3484, -57.2000];
    const map = L.map('map').setView(guichonCoords, 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // Marcadores de prueba en el mapa
    L.marker([-32.3484, -57.2000]).addTo(map).bindPopup('Centro de Guichón');
    L.marker([-32.3450, -57.1950]).addTo(map).bindPopup('Reporte en Vías');

    // 2. Cambio activo de pestañas de categoría + FILTRO de temas
    const tabButtons = document.querySelectorAll('.category-tabs .tab-item');
    const topicItems = document.querySelectorAll('.topic-item');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            const categoriaSeleccionada = button.dataset.category;

            topicItems.forEach(item => {
                const categoriaDelTema = item.dataset.category;

                if (categoriaSeleccionada === 'Todos' || categoriaDelTema === categoriaSeleccionada) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    // 3. Filtro rápido de búsqueda local
    const searchInput = document.getElementById('search-input');

    if (searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            const query = e.target.value.toLowerCase();
            topicItems.forEach(item => {
                const title = item.querySelector('.topic-title').textContent.toLowerCase();
                if (title.includes(query)) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }

    // 4. LIKE (corazón) - se pone rojo y suma/resta el contador
    const likeButtons = document.querySelectorAll('.stat-like');

    likeButtons.forEach(likeBtn => {
        likeBtn.addEventListener('click', () => {
            const countSpan = likeBtn.querySelector('.like-count');
            let count = parseInt(countSpan.textContent, 10);

            const yaLeDioLike = likeBtn.classList.contains('liked');

            if (yaLeDioLike) {
                // Quitar like
                likeBtn.classList.remove('liked');
                count -= 1;
            } else {
                // Dar like
                likeBtn.classList.add('liked');
                count += 1;
            }

            countSpan.textContent = count;
        });
    });
});