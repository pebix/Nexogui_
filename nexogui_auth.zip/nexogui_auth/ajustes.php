<?php
session_start();
require_once 'config/db.php';

// Si no hay sesión, mandar al login
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?view=login");
    exit;
}

// Traer los datos reales y actualizados del usuario desde la base de datos
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$usuario = $stmt->fetch();

if (!$usuario) {
    header("Location: index.php?view=login");
    exit;
}

$nombreUsuario    = $usuario['nombre'] . ' ' . $usuario['apellido'];
$rolUsuario       = ucfirst($usuario['rol']);
$emailUsuario     = $usuario['email'];
$telefonoUsuario  = $usuario['telefono'] ?? '';
$direccionUsuario = $usuario['direccion'] ?? '';
$biografiaUsuario = $usuario['biografia'] ?? '';

// Traer los reportes del usuario logueado, mas recientes primero
$stmtReportes = $pdo->prepare(
    "SELECT id, categoria, ubicacion, descripcion, foto, estado, fecha_creacion
     FROM reportes
     WHERE usuario_id = ?
     ORDER BY fecha_creacion DESC"
);
$stmtReportes->execute([$_SESSION['user_id']]);
$misReportes = $stmtReportes->fetchAll();

require_once 'i18n/i18n.php';
?>
<!DOCTYPE html>
<html lang="<?php echo $idiomaActual; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexoGÜI - <?php echo t('nav_ajustes'); ?></title>

    <!-- Librerías Externas -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <!-- CSS de Ajustes -->
    <link rel="stylesheet" href="css/ajustes.css">
</head>
<body>

<div class="dashboard-layout">
    
    <!-- BARRA LATERAL (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon"><span>N</span></div>
            <h1 class="logo-text">Nexo<span>GÜI</span></h1>
        </div>

        <nav class="sidebar-nav">
            <a href="inicio.php" class="nav-item">
                <i data-lucide="home"></i> <?php echo t('nav_inicio'); ?>
            </a>
            <a href="reportar.php" class="nav-item">
                <i data-lucide="plus-circle"></i> <?php echo t('nav_reportar'); ?>
            </a>
            <a href="foro.php" class="nav-item">
                <i data-lucide="message-square"></i> <?php echo t('nav_foro'); ?>
            </a>
            <a href="ajustes.php" class="nav-item active">
                <i data-lucide="settings"></i> <?php echo t('nav_ajustes'); ?>
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="avatar">
                    <i data-lucide="user"></i>
                </div>
                <div class="user-info">
                    <span class="user-name"><?php echo htmlspecialchars($nombreUsuario); ?></span>
                    <span class="user-role"><?php echo htmlspecialchars($rolUsuario); ?></span>
                </div>
                <i data-lucide="chevron-down" class="dropdown-icon"></i>
            </div>
        </div>
    </aside>

    <!-- CONTENIDO PRINCIPAL -->
    <main class="main-content">
        
        <!-- COLUMNA IZQUIERDA / PANEL DE AJUSTES -->
        <div class="content-left">
            
            <div class="settings-header">
                <div class="title-with-icon">
                    <i data-lucide="settings" class="settings-icon"></i>
                    <h2><?php echo t('page_heading'); ?></h2>
                </div>
                <p><?php echo t('page_subtitle'); ?></p>
            </div>

            <!-- Tarjeta Contenedora -->
            <div class="settings-card">
                
                <!-- Menú Lateral Interno de Ajustes -->
                <div class="settings-sidebar">
                    <button type="button" class="settings-nav-item active" data-tab="mi-cuenta">
                        <i data-lucide="user"></i>
                        <div>
                            <span class="nav-title"><?php echo t('tab_mi_cuenta_title'); ?></span>
                            <span class="nav-sub"><?php echo t('tab_mi_cuenta_sub'); ?></span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="notificaciones">
                        <i data-lucide="bell"></i>
                        <div>
                            <span class="nav-title"><?php echo t('tab_notif_title'); ?></span>
                            <span class="nav-sub"><?php echo t('tab_notif_sub'); ?></span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="mis-reportes">
                        <i data-lucide="file-text"></i>
                        <div>
                            <span class="nav-title"><?php echo t('tab_reportes_title'); ?></span>
                            <span class="nav-sub"><?php echo t('tab_reportes_sub'); ?></span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="privacidad">
                        <i data-lucide="shield"></i>
                        <div>
                            <span class="nav-title"><?php echo t('tab_privacidad_title'); ?></span>
                            <span class="nav-sub"><?php echo t('tab_privacidad_sub'); ?></span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="seguridad">
                        <i data-lucide="lock"></i>
                        <div>
                            <span class="nav-title"><?php echo t('tab_seguridad_title'); ?></span>
                            <span class="nav-sub"><?php echo t('tab_seguridad_sub'); ?></span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="idioma">
                        <i data-lucide="globe"></i>
                        <div>
                            <span class="nav-title"><?php echo t('tab_idioma_title'); ?></span>
                            <span class="nav-sub"><?php echo t('tab_idioma_sub'); ?></span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="apariencia">
                        <i data-lucide="palette"></i>
                        <div>
                            <span class="nav-title"><?php echo t('tab_apariencia_title'); ?></span>
                            <span class="nav-sub"><?php echo t('tab_apariencia_sub'); ?></span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="acerca-de">
                        <i data-lucide="info"></i>
                        <div>
                            <span class="nav-title"><?php echo t('tab_acerca_title'); ?></span>
                            <span class="nav-sub"><?php echo t('tab_acerca_sub'); ?></span>
                        </div>
                    </button>

                    <a href="logout.php" class="settings-nav-item logout-link">
                        <i data-lucide="log-out"></i>
                        <div>
                            <span class="nav-title"><?php echo t('tab_logout_title'); ?></span>
                            <span class="nav-sub"><?php echo t('tab_logout_sub'); ?></span>
                        </div>
                    </a>
                </div>

                <!-- CONTENIDOS DE LAS PESTAÑAS -->
                <div class="settings-body-wrapper">
                    
                    <!-- 1. MI CUENTA -->
                    <div class="settings-body tab-content active" id="tab-mi-cuenta">
                        <form action="process_settings.php" method="POST" enctype="multipart/form-data">
                            <div class="body-header">
                                <h3><?php echo t('acc_info_title'); ?></h3>
                                <div class="avatar-upload-wrapper">
                                    <div class="profile-avatar">
                                        <i data-lucide="user"></i>
                                    </div>
                                    <label for="avatar-input" class="camera-btn" title="Cambiar foto">
                                        <i data-lucide="camera"></i>
                                        <input type="file" id="avatar-input" name="avatar" accept="image/*" hidden>
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nombre"><?php echo t('label_nombre'); ?></label>
                                <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombreUsuario); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="email"><?php echo t('label_email'); ?></label>
                                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($emailUsuario); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="telefono"><?php echo t('label_telefono'); ?> <span class="optional"><?php echo t('label_opcional'); ?></span></label>
                                <input type="tel" id="telefono" name="telefono" value="<?php echo htmlspecialchars($telefonoUsuario); ?>">
                            </div>

                            <div class="form-group">
                                <label for="direccion"><?php echo t('label_direccion'); ?></label>
                                <input type="text" id="direccion" name="direccion" value="<?php echo htmlspecialchars($direccionUsuario); ?>">
                            </div>

                            <div class="form-group">
                                <label for="biografia"><?php echo t('label_biografia'); ?> <span class="optional"><?php echo t('label_opcional'); ?></span></label>
                                <textarea id="biografia" name="biografia" rows="4"><?php echo htmlspecialchars($biografiaUsuario); ?></textarea>
                            </div>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-save">
                                    <i data-lucide="save"></i> <?php echo t('btn_guardar'); ?>
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- 2. NOTIFICACIONES -->
                    <div class="settings-body tab-content" id="tab-notificaciones">
                        <div class="notifications-header">
                            <h3><?php echo t('tab_notif_title'); ?></h3>
                            <p class="section-desc"><?php echo t('notif_desc'); ?></p>
                        </div>

                        <div class="toggle-card">
                            <div class="toggle-info">
                                <span class="toggle-title"><?php echo t('notif_master_title'); ?></span>
                                <span class="toggle-desc"><?php echo t('notif_master_desc'); ?></span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-notifications-master" checked>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="notif-group" id="notif-preferences-group">
                            <span class="group-label"><?php echo t('notif_channels_label'); ?></span>
                            
                            <div class="notif-card">
                                <div class="notif-icon-circle blue-bg"><i data-lucide="mail"></i></div>
                                <div class="notif-details">
                                    <span class="notif-title"><?php echo t('label_email'); ?></span>
                                    <span class="notif-message"><?php echo t('notif_email_desc'); ?></span>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" class="sub-notif-toggle" checked>
                                    <span class="slider round"></span>
                                </label>
                            </div>

                            <div class="notif-card">
                                <div class="notif-icon-circle green-bg"><i data-lucide="smartphone"></i></div>
                                <div class="notif-details">
                                    <span class="notif-title"><?php echo t('notif_push_title'); ?></span>
                                    <span class="notif-message"><?php echo t('notif_push_desc'); ?></span>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" class="sub-notif-toggle" checked>
                                    <span class="slider round"></span>
                                </label>
                            </div>

                            <div class="notif-card">
                                <div class="notif-icon-circle orange-bg"><i data-lucide="message-square"></i></div>
                                <div class="notif-details">
                                    <span class="notif-title"><?php echo t('notif_sms_title'); ?></span>
                                    <span class="notif-message"><?php echo t('notif_sms_desc'); ?></span>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" class="sub-notif-toggle">
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </div>

                        <div class="notif-tabs" id="notif-filter-tabs">
                            <button type="button" class="notif-tab active" data-filter="all"><?php echo t('notif_tab_all'); ?></button>
                            <button type="button" class="notif-tab" data-filter="unread"><?php echo t('notif_tab_unread'); ?></button>
                            <button type="button" class="notif-tab" data-filter="important"><?php echo t('notif_tab_important'); ?></button>
                        </div>

                        <div class="notif-history-container">
                            <div class="notif-group">
                                <span class="group-label"><?php echo t('group_today'); ?></span>

                                <div class="notif-card unread" data-type="important">
                                    <div class="notif-icon-circle red-bg"><i data-lucide="bell"></i></div>
                                    <div class="notif-details">
                                        <span class="notif-title"><?php echo t('notif_item1_title'); ?></span>
                                        <span class="notif-message"><?php echo t('notif_item1_msg'); ?></span>
                                        <span class="notif-time"><?php echo t('time_10min'); ?></span>
                                    </div>
                                    <span class="unread-dot"></span>
                                </div>

                                <div class="notif-card unread" data-type="standard">
                                    <div class="notif-icon-circle orange-bg"><i data-lucide="construction"></i></div>
                                    <div class="notif-details">
                                        <span class="notif-title"><?php echo t('notif_item2_title'); ?></span>
                                        <span class="notif-message"><?php echo t('notif_item2_msg'); ?></span>
                                        <span class="notif-time"><?php echo t('time_1hr'); ?></span>
                                    </div>
                                    <span class="unread-dot"></span>
                                </div>

                                <div class="notif-card read" data-type="standard">
                                    <div class="notif-icon-circle green-bg"><i data-lucide="check"></i></div>
                                    <div class="notif-details">
                                        <span class="notif-title"><?php echo t('notif_item3_title'); ?></span>
                                        <span class="notif-message"><?php echo t('notif_item3_msg'); ?></span>
                                        <span class="notif-time"><?php echo t('time_2hr'); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="load-all-wrapper">
                            <button type="button" class="btn-outline-primary" id="btn-mark-all-read"><?php echo t('btn_mark_all_read'); ?></button>
                        </div>
                    </div>

                    <!-- 3. MIS REPORTES -->
                    <div class="settings-body tab-content" id="tab-mis-reportes">
                        <div class="notifications-header">
                            <h3><?php echo t('tab_reportes_title'); ?></h3>
                            <p class="section-desc"><?php echo t('reportes_desc'); ?></p>
                        </div>

                        <div class="toggle-card">
                            <div class="toggle-info">
                                <span class="toggle-title"><?php echo t('reportes_toggle_title'); ?></span>
                                <span class="toggle-desc"><?php echo t('reportes_toggle_desc'); ?></span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-report-notifs" checked>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="notif-tabs" id="report-filter-tabs">
                            <button type="button" class="notif-tab active" data-report-filter="all"><?php echo t('reportes_tab_all'); ?></button>
                            <button type="button" class="notif-tab" data-report-filter="pending"><?php echo t('reportes_tab_pending'); ?></button>
                            <button type="button" class="notif-tab" data-report-filter="solved"><?php echo t('reportes_tab_solved'); ?></button>
                        </div>

                        <div class="notif-history-container" id="reports-list">
                            <div class="notif-group">
                                <span class="group-label"><?php echo t('group_recientes'); ?></span>

                                <?php if (empty($misReportes)): ?>
                                    <p class="section-desc" style="text-align:center; padding: 24px 0;">
                                        <?php echo t('reportes_vacio') ?: 'Todavía no creaste ningún reporte.'; ?>
                                    </p>
                                <?php else: ?>
                                    <?php foreach ($misReportes as $reporte):
                                        $estado = $reporte['estado'];

                                        // Mapeo de estado real -> filtro visual (all / pending / solved)
                                        $filtroEstado = ($estado === 'resuelto') ? 'solved' : 'pending';
                                        $esLeido      = ($estado === 'resuelto') ? 'read' : 'unread';
                                        $iconoEstado  = ($estado === 'resuelto') ? 'check-circle-2' : 'clock';
                                        $colorEstado  = ($estado === 'resuelto') ? 'green-bg' : 'orange-bg';

                                        $estadoTexto = match ($estado) {
                                            'pendiente'  => 'Pendiente',
                                            'en_proceso' => 'En proceso',
                                            'resuelto'   => 'Resuelto',
                                            default      => ucfirst($estado),
                                        };

                                        $fechaFormateada = date('d/m/Y H:i', strtotime($reporte['fecha_creacion']));
                                    ?>
                                    <div class="notif-card <?php echo $esLeido; ?>"
                                         data-status="<?php echo $filtroEstado; ?>"
                                         data-report-id="<?php echo (int) $reporte['id']; ?>">

                                        <div class="notif-icon-circle <?php echo $colorEstado; ?>">
                                            <i data-lucide="<?php echo $iconoEstado; ?>"></i>
                                        </div>

                                        <div class="notif-details">
                                            <span class="notif-title">
                                                <?php echo htmlspecialchars($reporte['categoria']); ?> —
                                                <?php echo htmlspecialchars($reporte['ubicacion']); ?>
                                            </span>
                                            <span class="notif-message">
                                                <?php echo htmlspecialchars($reporte['descripcion']); ?>
                                            </span>
                                            <span class="notif-time">
                                                <?php echo $fechaFormateada; ?> · Estado: <strong><?php echo $estadoTexto; ?></strong>
                                            </span>
                                        </div>

                                        <button type="button"
                                                class="btn-delete-report"
                                                data-id="<?php echo (int) $reporte['id']; ?>"
                                                title="Eliminar reporte">
                                            <i data-lucide="trash-2"></i>
                                        </button>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="load-all-wrapper">
                            <a href="reportar.php" class="btn-outline-primary block-link"><?php echo t('btn_crear_reporte'); ?></a>
                        </div>
                    </div>

                    <!-- 4. PRIVACIDAD -->
                    <div class="settings-body tab-content" id="tab-privacidad">
                        <div class="notifications-header">
                            <h3><?php echo t('tab_privacidad_title'); ?></h3>
                            <p class="section-desc"><?php echo t('privacidad_desc'); ?></p>
                        </div>

                        <div class="privacy-select-card">
                            <div class="privacy-item-left">
                                <div class="privacy-icon"><i data-lucide="eye"></i></div>
                                <div>
                                    <span class="privacy-item-title"><?php echo t('priv_perfil_title'); ?></span>
                                    <span class="privacy-item-desc"><?php echo t('priv_perfil_desc'); ?></span>
                                </div>
                            </div>
                            <select class="privacy-select" id="perfil-visibilidad">
                                <option value="nombre-foto" selected><?php echo t('opt_nombre_foto'); ?></option>
                                <option value="solo-nombre"><?php echo t('opt_solo_nombre'); ?></option>
                                <option value="anonimo"><?php echo t('opt_anonimo'); ?></option>
                            </select>
                        </div>

                        <span class="privacy-section-subtitle"><?php echo t('priv_interaccion_subtitle'); ?></span>
                        
                        <div class="privacy-options-list">
                            <div class="privacy-option-item">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon"><i data-lucide="map-pin"></i></div>
                                    <div>
                                        <span class="privacy-item-title"><?php echo t('priv_ubicacion_title'); ?></span>
                                        <span class="privacy-item-desc"><?php echo t('priv_ubicacion_desc'); ?></span>
                                    </div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="toggle-map-profile">
                                    <span class="slider round"></span>
                                </label>
                            </div>

                            <div class="privacy-option-item">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon"><i data-lucide="message-square"></i></div>
                                    <div>
                                        <span class="privacy-item-title"><?php echo t('priv_mensajes_title'); ?></span>
                                        <span class="privacy-item-desc"><?php echo t('priv_mensajes_desc'); ?></span>
                                    </div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="toggle-allow-messages" checked>
                                    <span class="slider round"></span>
                                </label>
                            </div>

                            <div class="privacy-option-item">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon"><i data-lucide="globe"></i></div>
                                    <div>
                                        <span class="privacy-item-title"><?php echo t('priv_reportes_publicos_title'); ?></span>
                                        <span class="privacy-item-desc"><?php echo t('priv_reportes_publicos_desc'); ?></span>
                                    </div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="toggle-public-reports" checked>
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </div>

                        <span class="privacy-section-subtitle"><?php echo t('priv_datos_subtitle'); ?></span>

                        <div class="privacy-actions-list">
                            <button type="button" class="privacy-action-item" id="btn-download-data">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon"><i data-lucide="download"></i></div>
                                    <div>
                                        <span class="privacy-item-title"><?php echo t('priv_descargar_title'); ?></span>
                                        <span class="privacy-item-desc"><?php echo t('priv_descargar_desc'); ?></span>
                                    </div>
                                </div>
                                <i data-lucide="chevron-right" class="chevron-icon"></i>
                            </button>

                            <button type="button" class="privacy-action-item" id="btn-delete-account">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon" style="color: #ef4444;"><i data-lucide="trash-2"></i></div>
                                    <div>
                                        <span class="privacy-item-title" style="color: #ef4444;"><?php echo t('priv_eliminar_title'); ?></span>
                                        <span class="privacy-item-desc"><?php echo t('priv_eliminar_desc'); ?></span>
                                    </div>
                                </div>
                                <i data-lucide="chevron-right" class="chevron-icon"></i>
                            </button>
                        </div>
                    </div>

                    <!-- 5. SEGURIDAD -->
                    <div class="settings-body tab-content" id="tab-seguridad">
                        <div class="notifications-header">
                            <h3><?php echo t('tab_seguridad_title'); ?></h3>
                            <p class="section-desc"><?php echo t('seguridad_desc'); ?></p>
                        </div>

                        <div class="sec-card-box">
                            <div class="sec-card-left">
                                <div class="sec-card-icon"><i data-lucide="key-round"></i></div>
                                <div class="sec-card-text">
                                    <span class="sec-card-title"><?php echo t('sec_pass_title'); ?></span>
                                    <span class="sec-card-desc"><?php echo t('sec_pass_desc'); ?></span>
                                </div>
                            </div>
                            <button type="button" class="btn-sec-action btn-white" id="btn-change-pass"><?php echo t('btn_cambiar'); ?></button>
                        </div>

                        <div class="sec-card-box">
                            <div class="sec-card-left">
                                <div class="sec-card-icon"><i data-lucide="shield-check"></i></div>
                                <div class="sec-card-text">
                                    <span class="sec-card-title"><?php echo t('sec_2fa_title'); ?></span>
                                    <span class="sec-card-desc"><?php echo t('sec_2fa_desc'); ?></span>
                                </div>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-2fa" checked>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="sec-card-box col-layout">
                            <div class="sec-card-row">
                                <div class="sec-card-header">
                                    <div class="sec-card-icon"><i data-lucide="laptop"></i></div>
                                    <div class="sec-card-text">
                                        <span class="sec-card-title"><?php echo t('sec_sessions_title'); ?></span>
                                        <span class="sec-card-desc"><?php echo t('sec_sessions_desc'); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="sec-device-list">
                                <div class="sec-device-item">
                                    <div class="sec-device-left">
                                        <i data-lucide="monitor" class="device-icon"></i>
                                        <div class="sec-device-info">
                                            <span class="sec-device-title"><?php echo t('device1_title'); ?></span>
                                            <span class="sec-device-sub"><?php echo t('device1_sub'); ?></span>
                                        </div>
                                    </div>
                                    <span class="badge-this-device"><?php echo t('badge_this_device'); ?></span>
                                </div>

                                <div class="sec-device-item">
                                    <div class="sec-device-left">
                                        <i data-lucide="smartphone" class="device-icon"></i>
                                        <div class="sec-device-info">
                                            <span class="sec-device-title"><?php echo t('device2_title'); ?></span>
                                            <span class="sec-device-sub"><?php echo t('device2_sub'); ?></span>
                                        </div>
                                    </div>
                                    <button type="button" class="btn-danger-outline"><?php echo t('btn_cerrar'); ?></button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 6. IDIOMA -->
                    <div class="settings-body tab-content" id="tab-idioma">
                        <div class="notifications-header">
                            <h3><?php echo t('idioma_title'); ?></h3>
                            <p class="section-desc"><?php echo t('idioma_desc'); ?></p>
                        </div>
                        <form action="set_idioma.php" method="POST">
                            <div class="form-group">
                                <label for="idioma-select"><?php echo t('idioma_label'); ?></label>
                                <select id="idioma-select" name="idioma" class="privacy-select" style="width: 100%; padding: 12px;" onchange="this.form.submit()">
                                    <option value="es" <?php echo $idiomaActual === 'es' ? 'selected' : ''; ?>><?php echo t('opt_es'); ?></option>
                                    <option value="en" <?php echo $idiomaActual === 'en' ? 'selected' : ''; ?>><?php echo t('opt_en'); ?></option>
                                    <option value="pt" <?php echo $idiomaActual === 'pt' ? 'selected' : ''; ?>><?php echo t('opt_pt'); ?></option>
                                </select>
                            </div>
                        </form>
                    </div>

                    <!-- 7. APARIENCIA -->
                    <div class="settings-body tab-content" id="tab-apariencia">
                        <div class="notifications-header">
                            <h3><?php echo t('tab_apariencia_title'); ?></h3>
                            <p class="section-desc"><?php echo t('apariencia_desc'); ?></p>
                        </div>

                        <div class="theme-selection-grid">
                            <div class="theme-card active" data-theme="light">
                                <div class="theme-preview light-theme-preview">
                                    <div class="preview-header"></div>
                                    <div class="preview-body"></div>
                                </div>
                                <div class="theme-info">
                                    <span class="theme-title"><?php echo t('theme_light_title'); ?></span>
                                    <span class="theme-desc"><?php echo t('theme_light_desc'); ?></span>
                                </div>
                            </div>

                            <div class="theme-card" data-theme="dark">
                                <div class="theme-preview dark-theme-preview">
                                    <div class="preview-header"></div>
                                    <div class="preview-body"></div>
                                </div>
                                <div class="theme-info">
                                    <span class="theme-title"><?php echo t('theme_dark_title'); ?></span>
                                    <span class="theme-desc"><?php echo t('theme_dark_desc'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 8. ACERCA DE -->
                    <div class="settings-body tab-content" id="tab-acerca-de">
                        <div class="about-container">
                            <div class="about-header">
                                <div class="about-logo">N</div>
                                <h3>Nexo<span>GÜI</span></h3>
                                <span class="version-badge"><?php echo t('about_version'); ?></span>
                            </div>

                            <p class="about-description">
                                <?php echo t('about_desc'); ?>
                            </p>

                            <div class="about-meta-list">
                                <div class="about-meta-item">
                                    <span><?php echo t('about_desarrollado_para'); ?></span>
                                    <strong><?php echo t('about_desarrollado_valor'); ?></strong>
                                </div>
                                <div class="about-meta-item">
                                    <span><?php echo t('about_licencia'); ?></span>
                                    <strong><?php echo t('about_licencia_valor'); ?></strong>
                                </div>
                                <div class="about-meta-item">
                                    <span><?php echo t('about_soporte'); ?></span>
                                    <a href="mailto:soporte@nexogui.uy">soporte@nexogui.uy</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>

        <!-- COLUMNA DERECHA / MAPA Y CONTACTOS -->
        <div class="content-right">
            
            <div class="map-card">
                <div class="map-header">
                    <i data-lucide="map-pin" class="map-icon"></i>
                    <h3><?php echo t('map_title'); ?></h3>
                </div>
                <div id="map"></div>
            </div>

            <!-- Emergencias -->
            <div class="contact-card emergency">
                <div class="card-icon-round red">
                    <i data-lucide="siren"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label"><?php echo t('label_emergencias'); ?></span>
                    <span class="contact-number red-text">911</span>
                </div>
            </div>

            <!-- Municipio -->
            <div class="contact-card municipio">
                <div class="card-icon-round blue">
                    <i data-lucide="landmark"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label"><?php echo t('label_municipio'); ?></span>
                    <span class="contact-number blue-text">2200</span>
                </div>
            </div>

        </div>

    </main>

</div>

<!-- Scripts JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    lucide.createIcons();
</script>
<script src="js/ajustes.js"></script>
</body>
</html>