<?php
session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?view=login");
    exit;
}

$idiomasPermitidos = ['es', 'en', 'pt'];
$idioma = $_POST['idioma'] ?? 'es';

if (!in_array($idioma, $idiomasPermitidos)) {
    $idioma = 'es';
}

// Guardar en la sesión (cambio inmediato)
$_SESSION['idioma'] = $idioma;

// Guardar también en la base de datos (para que quede aunque cierre sesión)
try {
    $stmt = $pdo->prepare("UPDATE usuarios SET idioma = ? WHERE id = ?");
    $stmt->execute([$idioma, $_SESSION['user_id']]);
} catch (PDOException $e) {
    // Si falla el guardado en BD, no rompe nada: el idioma ya quedó en la sesión
}

header("Location: ajustes.php");
exit;