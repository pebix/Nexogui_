<?php
session_start();

// Datos del usuario desde la sesión
$nombreUsuario = $_SESSION['user_name'] ?? 'Juan Pérez';
$rolUsuario   = $_SESSION['user_role'] ?? 'Vecino';
$emailUsuario = $_SESSION['user_email'] ?? 'juan.perez@email.com';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexoGÜI - Ajustes</title>

    <!-- Librerías Externas -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <!-- CSS de Ajustes -->
    <link rel="stylesheet" href="css/ajustes.css">
</head>
<body>

<div class="dashboard-layout">
    
    <!-- BARRA LATERAL (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon"><span>N</span></div>
            <h1 class="logo-text">Nexo<span>GÜI</span></h1>
        </div>

        <nav class="sidebar-nav">
            <a href="inicio.php" class="nav-item">
                <i data-lucide="home"></i> Inicio
            </a>
            <a href="reportar.php" class="nav-item">
                <i data-lucide="plus-circle"></i> Reportar
            </a>
            <a href="foro.php" class="nav-item">
                <i data-lucide="message-square"></i> Foro
            </a>
            <a href="ajustes.php" class="nav-item active">
                <i data-lucide="settings"></i> Ajustes
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="avatar">
                    <i data-lucide="user"></i>
                </div>
                <div class="user-info">
                    <span class="user-name"><?php echo htmlspecialchars($nombreUsuario); ?></span>
                    <span class="user-role"><?php echo htmlspecialchars($rolUsuario); ?></span>
                </div>
                <i data-lucide="chevron-down" class="dropdown-icon"></i>
            </div>
        </div>
    </aside>

    <!-- CONTENIDO PRINCIPAL -->
    <main class="main-content">
        
        <!-- COLUMNA IZQUIERDA / PANEL DE AJUSTES -->
        <div class="content-left">
            
            <!-- Encabezado de la página -->
            <div class="settings-header">
                <div class="title-with-icon">
                    <i data-lucide="settings" class="settings-icon"></i>
                    <h2>AJUSTES</h2>
                </div>
                <p>Personalizá tu experiencia y gestioná tu cuenta.</p>
            </div>

            <!-- Tarjeta Contenedora de Ajustes -->
            <div class="settings-card">
                
                <!-- Menú Lateral Interno de Ajustes -->
                <div class="settings-sidebar">
                    <button class="settings-nav-item active" data-tab="mi-cuenta">
                        <i data-lucide="user"></i>
                        <div>
                            <span class="nav-title">Mi cuenta</span>
                            <span class="nav-sub">Información personal</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="notificaciones">
                        <i data-lucide="bell"></i>
                        <div>
                            <span class="nav-title">Notificaciones</span>
                            <span class="nav-sub">Preferencias y alertas</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="mis-reportes">
                        <i data-lucide="file-text"></i>
                        <div>
                            <span class="nav-title">Mis reportes</span>
                            <span class="nav-sub">Historial y seguimiento</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="privacidad">
                        <i data-lucide="shield"></i>
                        <div>
                            <span class="nav-title">Privacidad</span>
                            <span class="nav-sub">Seguridad y datos</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="seguridad">
                        <i data-lucide="lock"></i>
                        <div>
                            <span class="nav-title">Seguridad</span>
                            <span class="nav-sub">Contraseña y verificación</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="idioma">
                        <i data-lucide="globe"></i>
                        <div>
                            <span class="nav-title">Idioma</span>
                            <span class="nav-sub">Idioma de la aplicación</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="apariencia">
                        <i data-lucide="palette"></i>
                        <div>
                            <span class="nav-title">Apariencia</span>
                            <span class="nav-sub">Tema y visualización</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="acerca-de">
                        <i data-lucide="info"></i>
                        <div>
                            <span class="nav-title">Acerca de</span>
                            <span class="nav-sub">Info de la aplicación</span>
                        </div>
                    </button>

                    <a href="logout.php" class="settings-nav-item logout-link">
                        <i data-lucide="log-out"></i>
                        <div>
                            <span class="nav-title">Cerrar sesión</span>
                            <span class="nav-sub">Salir de tu cuenta</span>
                        </div>
                    </a>
                </div>

                <!-- CONTENIDOS DE LAS PESTAÑAS -->
                
                <!-- 1. MI CUENTA (ACTIVA POR DEFECTO) -->
                <div class="settings-body tab-content active" id="tab-mi-cuenta">
                    <form action="process_settings.php" method="POST" enctype="multipart/form-data">
                        <div class="body-header">
                            <h3>Información de la cuenta</h3>
                            <div class="avatar-upload-wrapper">
                                <div class="profile-avatar">
                                    <i data-lucide="user"></i>
                                </div>
                                <label for="avatar-input" class="camera-btn" title="Cambiar foto">
                                    <i data-lucide="camera"></i>
                                    <input type="file" id="avatar-input" name="avatar" accept="image/*" hidden>
                                </label>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="nombre">Nombre completo</label>
                            <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombreUsuario); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Correo electrónico</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($emailUsuario); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="telefono">Teléfono <span class="optional">(opcional)</span></label>
                            <input type="tel" id="telefono" name="telefono" value="098 765 432">
                        </div>

                        <div class="form-group">
                            <label for="direccion">Dirección</label>
                            <input type="text" id="direccion" name="direccion" value="Guichón, Paysandú, Uruguay">
                        </div>

                        <div class="form-group">
                            <label for="biografia">Biografía <span class="optional">(opcional)</span></label>
                            <textarea id="biografia" name="biografia" rows="4">Vecino comprometido con la comunidad.</textarea>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-save">
                                <i data-lucide="save"></i> GUARDAR CAMBIOS
                            </button>
                        </div>
                    </form>
                </div>

                <!-- 2. NOTIFICACIONES -->
                <div class="settings-body tab-content" id="tab-notificaciones">
                    <div class="notifications-header">
                        <h3>Notificaciones</h3>
                        <p class="section-desc">Elegí cómo y cuándo querés recibir notificaciones.</p>
                    </div>

                    <div class="toggle-card">
                        <div class="toggle-info">
                            <span class="toggle-title">Notificaciones activadas</span>
                            <span class="toggle-desc">Recibirás alertas sobre reportes, comentarios y actualizaciones importantes.</span>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="toggle-notifications" checked>
                            <span class="slider round"></span>
                        </label>
                    </div>

                    <div class="notif-tabs">
                        <button class="notif-tab active">Todas</button>
                    </div>

                    <div class="notif-group">
                        <span class="group-label">Hoy</span>

                        <div class="notif-card">
                            <div class="notif-icon-circle red-bg"><i data-lucide="bell"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Nuevo reporte recibido</span>
                                <span class="notif-message">Se ha recibido un nuevo reporte en tu zona.</span>
                                <span class="notif-time">Hace 10 min</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle orange-bg"><i data-lucide="construction"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Reporte en revisión</span>
                                <span class="notif-message">El reporte #RPT-2024-000120 está siendo revisado.</span>
                                <span class="notif-time">Hace 1 hora</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle green-bg"><i data-lucide="check"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Reporte solucionado</span>
                                <span class="notif-message">El reporte #RPT-2024-000115 fue solucionado.</span>
                                <span class="notif-time">Hace 2 horas</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle blue-bg"><i data-lucide="info"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Nuevo comentario</span>
                                <span class="notif-message">Vecino123 comentó en el reporte #RPT-2024-000110.</span>
                                <span class="notif-time">Ayer, 18:30</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>
                    </div>

                    <div class="notif-group">
                        <span class="group-label">Ayer</span>
                        <div class="notif-card">
                            <div class="notif-icon-circle blue-bg"><i data-lucide="info"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Actualización de estado</span>
                                <span class="notif-message">El reporte #RPT-2024-000108 cambió de estado.</span>
                                <span class="notif-time">Ayer, 15:45</span>
                            </div>
                        </div>
                    </div>

                    <div class="load-all-wrapper">
                        <button class="btn-outline-primary">Ver todas las notificaciones</button>
                    </div>
                </div>

                <!-- 3. MIS REPORTES -->
                <div class="settings-body tab-content" id="tab-mis-reportes">
                    <h3>Mis Reportes</h3>
                    <p class="section-desc">Historial e información de tus publicaciones enviadas.</p>
                    <p style="color: #64748b; font-size: 0.9rem;">Acá se desplegarán tus reportes realizados.</p>
                </div>

                <!-- 4. PRIVACIDAD -->
                <div class="settings-body tab-content" id="tab-privacidad">
                    <h3>Privacidad</h3>
                    <p class="section-desc">Gestioná la visibilidad de tu perfil y tus datos.</p>
                    <p style="color: #64748b; font-size: 0.9rem;">Opciones de visibilidad pública/privada.</p>
                </div>

                <!-- 5. SEGURIDAD -->
                <div class="settings-body tab-content" id="tab-seguridad">
                    <h3>Seguridad</h3>
                    <p class="section-desc">Cambiá tu contraseña y administrá tu cuenta.</p>
                    <p style="color: #64748b; font-size: 0.9rem;">Formulario para cambiar contraseña.</p>
                </div>

                <!-- 6. IDIOMA -->
                <div class="settings-body tab-content" id="tab-idioma">
                    <h3>Idioma</h3>
                    <p class="section-desc">Selecciona el idioma preferido de la aplicación.</p>
                    <p style="color: #64748b; font-size: 0.9rem;">Español (Uruguay)</p>
                </div>

                <!-- 7. APARIENCIA -->
                <div class="settings-body tab-content" id="tab-apariencia">
                    <h3>Apariencia</h3>
                    <p class="section-desc">Personalizá el tema y colores de la pantalla.</p>
                    <p style="color: #64748b; font-size: 0.9rem;">Modo Claro / Modo Oscuro.</p>
                </div>

                <!-- 8. ACERCA DE -->
                <div class="settings-body tab-content" id="tab-acerca-de">
                    <h3>Acerca de</h3>
                    <p class="section-desc">Información sobre NexoGÜI.</p>
                    <p style="color: #64748b; font-size: 0.9rem;">Versión 1.0.0 - Desarrollado para Guichón.</p>
                </div>

            </div>

        </div>

        <!-- COLUMNA DERECHA / MAPA Y CONTACTOS -->
        <div class="content-right">
            
            <div class="map-card">
                <div class="map-header">
                    <i data-lucide="map-pin" class="map-icon"></i>
                    <h3>MAPA DE GUICHÓN</h3>
                </div>
                <div id="map"></div>
            </div>

            <!-- Emergencias -->
            <div class="contact-card emergency">
                <div class="card-icon-round red">
                    <i data-lucide="siren"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Emergencias:</span>
                    <span class="contact-number red-text">911</span>
                </div>
            </div>

            <!-- Municipio -->
            <div class="contact-card municipio">
                <div class="card-icon-round blue">
                    <i data-lucide="landmark"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Municipio:</span>
                    <span class="contact-number blue-text">2200</span>
                </div>
            </div>

        </div>

    </main>

</div>

<!-- Scripts JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    lucide.createIcons();
</script>
<script src="js/ajustes.js"></script>
</body>
</html>