document.addEventListener("DOMContentLoaded", () => {
    // 1. Inicializar Mapa de Guichón
    const mapElement = document.getElementById('map');
    if (mapElement) {
        const guichonCoords = [-32.3484, -57.2000];
        const map = L.map('map').setView(guichonCoords, 14);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        L.marker(guichonCoords).addTo(map).bindPopup('Guichón');
    }

    // 2. Cambio de Pestañas
    const navItems = document.querySelectorAll('.settings-nav-item[data-tab]');
    const tabContents = document.querySelectorAll('.tab-content');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const targetTab = item.getAttribute('data-tab');

            // Desactivar todos los botones y ocultar vistas
            navItems.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Activar botón seleccionado
            item.classList.add('active');

            // Mostrar el contenedor correspondiente
            const targetContent = document.getElementById(`tab-${targetTab}`);
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });

    // 3. Previsualización de Avatar
    const avatarInput = document.getElementById('avatar-input');
    if (avatarInput) {
        avatarInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    const avatarBox = document.querySelector('.profile-avatar');
                    avatarBox.innerHTML = `<img src="${event.target.result}" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">`;
                };
                reader.readAsDataURL(file);
            }
        });
    }
});