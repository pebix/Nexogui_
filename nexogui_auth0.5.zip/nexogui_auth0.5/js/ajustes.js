document.addEventListener('DOMContentLoaded', () => {

    // 1. CAMBIO DE PESTAÑAS DEL MENÚ LATERAL (CORREGIDO)
    const navButtons = document.querySelectorAll('.settings-nav-item[data-tab]');
    const tabContents = document.querySelectorAll('.tab-content');

    navButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Obtiene siempre el contenedor del botón aunque se haga clic en un icono o span
            const targetButton = e.target.closest('.settings-nav-item');
            if (!targetButton) return;

            const targetTab = targetButton.getAttribute('data-tab');

            // Cambiar clase activa en los botones
            navButtons.forEach(btn => btn.classList.remove('active'));
            targetButton.classList.add('active');

            // Mostrar el contenido correspondiente
            tabContents.forEach(content => {
                if (content.id === `tab-${targetTab}`) {
                    content.classList.add('active');
                } else {
                    content.classList.remove('active');
                }
            });
        });
    });

    // 2. NOTIFICACIONES - MASTER TOGGLE
    const masterSwitch = document.getElementById('toggle-notifications-master');
    const preferencesGroup = document.getElementById('notif-preferences-group');
    const subToggles = document.querySelectorAll('.sub-notif-toggle');

    if (masterSwitch && preferencesGroup) {
        masterSwitch.addEventListener('change', () => {
            const isEnabled = masterSwitch.checked;
            preferencesGroup.style.opacity = isEnabled ? '1' : '0.5';
            preferencesGroup.style.pointerEvents = isEnabled ? 'auto' : 'none';

            subToggles.forEach(toggle => {
                toggle.disabled = !isEnabled;
            });
        });
    }

    // FILTROS DE HISTORIAL DE NOTIFICACIONES
    const filterTabs = document.querySelectorAll('#notif-filter-tabs .notif-tab');
    const notifCards = document.querySelectorAll('.notif-history-container .notif-card');

    filterTabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            const targetTab = e.target.closest('.notif-tab');
            if (!targetTab) return;

            filterTabs.forEach(t => t.classList.remove('active'));
            targetTab.classList.add('active');

            const filterValue = targetTab.getAttribute('data-filter');

            notifCards.forEach(card => {
                if (filterValue === 'unread') {
                    card.style.display = card.classList.contains('unread') ? 'flex' : 'none';
                } else if (filterValue === 'important') {
                    card.style.display = (card.getAttribute('data-type') === 'important') ? 'flex' : 'none';
                } else {
                    card.style.display = 'flex';
                }
            });
        });
    });

    // BOTÓN MARCAR TODAS COMO LEÍDAS
    const btnMarkAllRead = document.getElementById('btn-mark-all-read');
    if (btnMarkAllRead) {
        btnMarkAllRead.addEventListener('click', () => {
            const unreadDots = document.querySelectorAll('.unread-dot');
            const unreadCards = document.querySelectorAll('.notif-card.unread');

            unreadCards.forEach(card => {
                card.classList.remove('unread');
                card.classList.add('read');
            });

            unreadDots.forEach(dot => dot.remove());

            btnMarkAllRead.textContent = 'Todas leídas';
            btnMarkAllRead.disabled = true;
            btnMarkAllRead.style.opacity = '0.6';
        });
    }

    // 3. FILTROS DE MIS REPORTES
    const reportFilterTabs = document.querySelectorAll('#report-filter-tabs .notif-tab');
    const reportCards = document.querySelectorAll('#reports-list .notif-card');

    reportFilterTabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            const targetTab = e.target.closest('.notif-tab');
            if (!targetTab) return;

            reportFilterTabs.forEach(t => t.classList.remove('active'));
            targetTab.classList.add('active');

            const statusFilter = targetTab.getAttribute('data-report-filter');

            reportCards.forEach(card => {
                if (statusFilter === 'all') {
                    card.style.display = 'flex';
                } else {
                    card.style.display = (card.getAttribute('data-status') === statusFilter) ? 'flex' : 'none';
                }
            });
        });
    });

    // 4. SECCIÓN APARIENCIA (CAMBIO VISUAL DE TEMA)
    const themeCards = document.querySelectorAll('.theme-card');
    themeCards.forEach(card => {
        card.addEventListener('click', (e) => {
            const targetCard = e.target.closest('.theme-card');
            if (!targetCard) return;

            themeCards.forEach(c => c.classList.remove('active'));
            targetCard.classList.add('active');
        });
    });

    // 5. MAPA DE LEAFLET
    const mapElement = document.getElementById('map');
    if (mapElement) {
        const guichonCoords = [-32.3558, -57.2033];
        const map = L.map('map').setView(guichonCoords, 14);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap'
        }).addTo(map);

        L.marker(guichonCoords).addTo(map)
            .bindPopup('Municipio de Guichón')
            .openPopup();
    }
});