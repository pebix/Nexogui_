<?php
session_start();

// Datos de sesión del usuario
$nombreUsuario = $_SESSION['user_name'] ?? 'Juan Pérez';
$rolUsuario   = $_SESSION['user_role'] ?? 'Vecino';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexoGÜI - Foro Comunitario</title>

    <!-- Librerías Externas -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <!-- CSS del Foro -->
    <link rel="stylesheet" href="css/foro.css">
</head>
<body>

<div class="dashboard-layout">
    
    <!-- BARRA LATERAL (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon"><span>N</span></div>
            <h1 class="logo-text">Nexo<span>GÜI</span></h1>
        </div>

        <nav class="sidebar-nav">
            <a href="inicio.php" class="nav-item">
                <i data-lucide="home"></i> Inicio
            </a>
            <a href="reportar.php" class="nav-item">
                <i data-lucide="plus-circle"></i> Reportar
            </a>
            <a href="foro.php" class="nav-item active">
                <i data-lucide="message-square"></i> Foro
            </a>
            <a href="ajustes.php" class="nav-item">
                <i data-lucide="settings"></i> Ajustes
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="avatar">
                    <i data-lucide="user"></i>
                </div>
                <div class="user-info">
                    <span class="user-name"><?php echo htmlspecialchars($nombreUsuario); ?></span>
                    <span class="user-role"><?php echo htmlspecialchars($rolUsuario); ?></span>
                </div>
                <i data-lucide="chevron-down" class="dropdown-icon"></i>
            </div>
        </div>
    </aside>

    <!-- CONTENIDO PRINCIPAL (2 COLUMNAS) -->
    <main class="main-content">
        
        <!-- COLUMNA IZQUIERDA / FORO Y PUBLICACIÓN -->
        <div class="content-left">
            
            <!-- Encabezado del Foro -->
            <div class="forum-top-header">
                <div class="forum-title-group">
                    <div class="title-with-icon">
                        <i data-lucide="message-square" class="forum-icon"></i>
                        <h2>FORO COMUNITARIO</h2>
                    </div>
                    <p>Compartí ideas, comentarios y soluciones con tu comunidad.</p>
                </div>
                <button class="btn btn-primary" id="btn-new-topic">
                    <i data-lucide="plus"></i> NUEVO TEMA
                </button>
            </div>

            <!-- Pestañas de Filtro Categorías -->
            <div class="category-tabs">
                <button class="tab-item active">Todos</button>
                <button class="tab-item">Generales</button>
                <button class="tab-item">Vías</button>
                <button class="tab-item">Alumbrado</button>
                <button class="tab-item">Parques</button>
                <button class="tab-item">Agua</button>
                <button class="tab-item">Sugerencias</button>
            </div>

            <!-- Buscador interno -->
            <div class="search-bar-wrapper">
                <i data-lucide="search" class="search-icon"></i>
                <input type="text" placeholder="Buscar en el foro..." id="search-input">
            </div>

            <!-- Tarjeta Principal con Lista de Temas -->
            <div class="topics-card">
                <div class="topics-header">
                    <span class="section-label">TEMAS RECIENTES</span>
                    <div class="sort-wrapper">
                        <span>ORDENAR POR:</span>
                        <select id="sort-select">
                            <option value="recent">Más recientes</option>
                            <option value="popular">Más populares</option>
                        </select>
                    </div>
                </div>

                <!-- Lista de publicaciones -->
                <div class="topics-list">
                    
                    <!-- Tema 1 -->
                    <div class="topic-item">
                        <div class="topic-icon icon-vias">
                            <i data-lucide="milestone"></i>
                        </div>
                        <div class="topic-details">
                            <h3 class="topic-title">Veces en mal estado en calle 18 de Julio</h3>
                            <div class="topic-meta">
                                <span class="badge badge-vias">Vías</span>
                                <span class="dot">•</span>
                                <span class="author">Juan Pérez</span>
                                <span class="dot">•</span>
                                <span class="time">Hoy, 10:32</span>
                            </div>
                        </div>
                        <div class="topic-stats">
                            <span class="stat"><i data-lucide="message-square"></i> 12</span>
                            <span class="stat"><i data-lucide="heart"></i> 8</span>
                        </div>
                    </div>

                    <!-- Tema 2 -->
                    <div class="topic-item">
                        <div class="topic-icon icon-alumbrado">
                            <i data-lucide="lightbulb"></i>
                        </div>
                        <div class="topic-details">
                            <h3 class="topic-title">Alumbrado apagado en Mevir 3</h3>
                            <div class="topic-meta">
                                <span class="badge badge-alumbrado">Alumbrado</span>
                                <span class="dot">•</span>
                                <span class="author">María González</span>
                                <span class="dot">•</span>
                                <span class="time">Ayer, 21:15</span>
                            </div>
                        </div>
                        <div class="topic-stats">
                            <span class="stat"><i data-lucide="message-square"></i> 7</span>
                            <span class="stat"><i data-lucide="heart"></i> 5</span>
                        </div>
                    </div>

                    <!-- Tema 3 -->
                    <div class="topic-item">
                        <div class="topic-icon icon-parques">
                            <i data-lucide="trees"></i>
                        </div>
                        <div class="topic-details">
                            <h3 class="topic-title">Necesitamos más árboles en la plaza </h3>
                            <div class="topic-meta">
                                <span class="badge badge-parques">Parques</span>
                                <span class="dot">•</span>
                                <span class="author">Andrés Silva</span>
                                <span class="dot">•</span>
                                <span class="time">Ayer, 18:47</span>
                            </div>
                        </div>
                        <div class="topic-stats">
                            <span class="stat"><i data-lucide="message-square"></i> 9</span>
                            <span class="stat"><i data-lucide="heart"></i> 6</span>
                        </div>
                    </div>

                    <!-- Tema 4 -->
                    <div class="topic-item">
                        <div class="topic-icon icon-agua">
                            <i data-lucide="droplet"></i>
                        </div>
                        <div class="topic-details">
                            <h3 class="topic-title">Baja presión de agua en barrio sur</h3>
                            <div class="topic-meta">
                                <span class="badge badge-agua">Agua</span>
                                <span class="dot">•</span>
                                <span class="author">Laura Fernández</span>
                                <span class="dot">•</span>
                                <span class="time">14/05/2025</span>
                            </div>
                        </div>
                        <div class="topic-stats">
                            <span class="stat"><i data-lucide="message-square"></i> 5</span>
                            <span class="stat"><i data-lucide="heart"></i> 4</span>
                        </div>
                    </div>

                    <!-- Tema 5 -->
                    <div class="topic-item">
                        <div class="topic-icon icon-sugerencias">
                            <i data-lucide="message-circle"></i>
                        </div>
                        <div class="topic-details">
                            <h3 class="topic-title">Ideas para mejorar el transporte público</h3>
                            <div class="topic-meta">
                                <span class="badge badge-sugerencias">Sugerencias</span>
                                <span class="dot">•</span>
                                <span class="author">Pedro Ramírez</span>
                                <span class="dot">•</span>
                                <span class="time">13/05/2025</span>
                            </div>
                        </div>
                        <div class="topic-stats">
                            <span class="stat"><i data-lucide="message-square"></i> 11</span>
                            <span class="stat"><i data-lucide="heart"></i> 9</span>
                        </div>
                    </div>

                </div>

                <!-- Botón Cargar Más -->
                <div class="load-more-wrapper">
                    <button class="btn-load-more">
                        CARGAR MÁS TEMAS <i data-lucide="chevron-down"></i>
                    </button>
                </div>
            </div>

            <!-- Caja para PUBLICAR EN EL FORO -->
            <div class="publish-card">
                <h3>PUBLICAR EN EL FORO</h3>
                <form action="process_post.php" method="POST" id="publish-form">
                    <div class="input-avatar-wrapper">
                        <div class="avatar-circle">
                            <i data-lucide="user"></i>
                        </div>
                        <textarea name="contenido" placeholder="¿Qué querés compartir con tu comunidad?" required></textarea>
                    </div>
                    <div class="publish-actions">
                        <div class="media-buttons">
                            <button type="button" class="icon-btn" title="Adjuntar imagen"><i data-lucide="image"></i></button>
                            <button type="button" class="icon-btn" title="Agregar ubicación"><i data-lucide="map-pin"></i></button>
                            <button type="button" class="icon-btn" title="Agregar emoji"><i data-lucide="smile"></i></button>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i data-lucide="send"></i> PUBLICAR
                        </button>
                    </div>
                </form>
            </div>

        </div>

        <!-- COLUMNA DERECHA / MAPA Y CONTACTOS -->
        <div class="content-right">
            
            <div class="map-card">
                <div class="map-header">
                    <i data-lucide="map-pin" class="map-icon"></i>
                    <h3>MAPA DE GUICHÓN</h3>
                </div>
                <div id="map"></div>
            </div>

            <!-- Emergencias -->
            <div class="contact-card emergency">
                <div class="card-icon-round red">
                    <i data-lucide="siren"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Emergencias:</span>
                    <span class="contact-number red-text">911</span>
                </div>
            </div>

            <!-- Municipio -->
            <div class="contact-card municipio">
                <div class="card-icon-round blue">
                    <i data-lucide="landmark"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Municipio:</span>
                    <span class="contact-number blue-text">2200</span>
                </div>
            </div>

        </div>

    </main>

</div>

<!-- Scripts JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    lucide.createIcons();
</script>
<script src="js/foro.js"></script>
</body>
</html>