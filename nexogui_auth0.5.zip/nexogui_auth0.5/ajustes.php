<?php
session_start();

// Datos del usuario desde la sesión
$nombreUsuario = $_SESSION['user_name'] ?? 'Juan Pérez';
$rolUsuario   = $_SESSION['user_role'] ?? 'Vecino';
$emailUsuario = $_SESSION['user_email'] ?? 'juan.perez@email.com';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexoGÜI - Ajustes</title>

    <!-- Librerías Externas -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <!-- CSS de Ajustes -->
    <link rel="stylesheet" href="css/ajustes.css">
</head>
<body>

<div class="dashboard-layout">
    
    <!-- BARRA LATERAL (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon"><span>N</span></div>
            <h1 class="logo-text">Nexo<span>GÜI</span></h1>
        </div>

        <nav class="sidebar-nav">
            <a href="inicio.php" class="nav-item">
                <i data-lucide="home"></i> Inicio
            </a>
            <a href="reportar.php" class="nav-item">
                <i data-lucide="plus-circle"></i> Reportar
            </a>
            <a href="foro.php" class="nav-item">
                <i data-lucide="message-square"></i> Foro
            </a>
            <a href="ajustes.php" class="nav-item active">
                <i data-lucide="settings"></i> Ajustes
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="avatar">
                    <i data-lucide="user"></i>
                </div>
                <div class="user-info">
                    <span class="user-name"><?php echo htmlspecialchars($nombreUsuario); ?></span>
                    <span class="user-role"><?php echo htmlspecialchars($rolUsuario); ?></span>
                </div>
                <i data-lucide="chevron-down" class="dropdown-icon"></i>
            </div>
        </div>
    </aside>

    <!-- CONTENIDO PRINCIPAL -->
    <main class="main-content">
        
        <!-- COLUMNA IZQUIERDA / PANEL DE AJUSTES -->
        <div class="content-left">
            
            <div class="settings-header">
                <div class="title-with-icon">
                    <i data-lucide="settings" class="settings-icon"></i>
                    <h2>AJUSTES</h2>
                </div>
                <p>Personalizá tu experiencia y gestioná tu cuenta.</p>
            </div>

            <!-- Tarjeta Contenedora -->
            <div class="settings-card">
                
                <!-- Menú Lateral Interno de Ajustes -->
                <div class="settings-sidebar">
                    <button type="button" class="settings-nav-item active" data-tab="mi-cuenta">
                        <i data-lucide="user"></i>
                        <div>
                            <span class="nav-title">Mi cuenta</span>
                            <span class="nav-sub">Información personal</span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="notificaciones">
                        <i data-lucide="bell"></i>
                        <div>
                            <span class="nav-title">Notificaciones</span>
                            <span class="nav-sub">Preferencias y alertas</span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="mis-reportes">
                        <i data-lucide="file-text"></i>
                        <div>
                            <span class="nav-title">Mis reportes</span>
                            <span class="nav-sub">Historial y seguimiento</span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="privacidad">
                        <i data-lucide="shield"></i>
                        <div>
                            <span class="nav-title">Privacidad</span>
                            <span class="nav-sub">Seguridad y datos</span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="seguridad">
                        <i data-lucide="lock"></i>
                        <div>
                            <span class="nav-title">Seguridad</span>
                            <span class="nav-sub">Contraseña y verificación</span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="idioma">
                        <i data-lucide="globe"></i>
                        <div>
                            <span class="nav-title">Idioma</span>
                            <span class="nav-sub">Idioma de la aplicación</span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="apariencia">
                        <i data-lucide="palette"></i>
                        <div>
                            <span class="nav-title">Apariencia</span>
                            <span class="nav-sub">Tema y visualización</span>
                        </div>
                    </button>

                    <button type="button" class="settings-nav-item" data-tab="acerca-de">
                        <i data-lucide="info"></i>
                        <div>
                            <span class="nav-title">Acerca de</span>
                            <span class="nav-sub">Info de la aplicación</span>
                        </div>
                    </button>

                    <a href="logout.php" class="settings-nav-item logout-link">
                        <i data-lucide="log-out"></i>
                        <div>
                            <span class="nav-title">Cerrar sesión</span>
                            <span class="nav-sub">Salir de tu cuenta</span>
                        </div>
                    </a>
                </div>

                <!-- CONTENIDOS DE LAS PESTAÑAS -->
                <div class="settings-body-wrapper">
                    
                    <!-- 1. MI CUENTA -->
                    <div class="settings-body tab-content active" id="tab-mi-cuenta">
                        <form action="process_settings.php" method="POST" enctype="multipart/form-data">
                            <div class="body-header">
                                <h3>Información de la cuenta</h3>
                                <div class="avatar-upload-wrapper">
                                    <div class="profile-avatar">
                                        <i data-lucide="user"></i>
                                    </div>
                                    <label for="avatar-input" class="camera-btn" title="Cambiar foto">
                                        <i data-lucide="camera"></i>
                                        <input type="file" id="avatar-input" name="avatar" accept="image/*" hidden>
                                    </label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="nombre">Nombre completo</label>
                                <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombreUsuario); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="email">Correo electrónico</label>
                                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($emailUsuario); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="telefono">Teléfono <span class="optional">(opcional)</span></label>
                                <input type="tel" id="telefono" name="telefono" value="098 765 432">
                            </div>

                            <div class="form-group">
                                <label for="direccion">Dirección</label>
                                <input type="text" id="direccion" name="direccion" value="Guichón, Paysandú, Uruguay">
                            </div>

                            <div class="form-group">
                                <label for="biografia">Biografía <span class="optional">(opcional)</span></label>
                                <textarea id="biografia" name="biografia" rows="4">Vecino comprometido con la comunidad.</textarea>
                            </div>

                            <div class="form-actions">
                                <button type="submit" class="btn btn-save">
                                    <i data-lucide="save"></i> GUARDAR CAMBIOS
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- 2. NOTIFICACIONES -->
                    <div class="settings-body tab-content" id="tab-notificaciones">
                        <div class="notifications-header">
                            <h3>Notificaciones</h3>
                            <p class="section-desc">Elegí cómo y cuándo querés recibir alertas en NexoGÜI.</p>
                        </div>

                        <div class="toggle-card">
                            <div class="toggle-info">
                                <span class="toggle-title">Notificaciones activadas</span>
                                <span class="toggle-desc">Permite recibir alertas generales sobre tu actividad y reportes en tu zona.</span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-notifications-master" checked>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="notif-group" id="notif-preferences-group">
                            <span class="group-label">Canales de notificación</span>
                            
                            <div class="notif-card">
                                <div class="notif-icon-circle blue-bg"><i data-lucide="mail"></i></div>
                                <div class="notif-details">
                                    <span class="notif-title">Correo electrónico</span>
                                    <span class="notif-message">Recibir resúmenes y alertas importantes en tu email.</span>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" class="sub-notif-toggle" checked>
                                    <span class="slider round"></span>
                                </label>
                            </div>

                            <div class="notif-card">
                                <div class="notif-icon-circle green-bg"><i data-lucide="smartphone"></i></div>
                                <div class="notif-details">
                                    <span class="notif-title">Notificaciones Push</span>
                                    <span class="notif-message">Alertas instantáneas en el navegador o dispositivo móvil.</span>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" class="sub-notif-toggle" checked>
                                    <span class="slider round"></span>
                                </label>
                            </div>

                            <div class="notif-card">
                                <div class="notif-icon-circle orange-bg"><i data-lucide="message-square"></i></div>
                                <div class="notif-details">
                                    <span class="notif-title">Mensajes SMS / WhatsApp</span>
                                    <span class="notif-message">Alertas de emergencias comunitarias de alta prioridad.</span>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" class="sub-notif-toggle">
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </div>

                        <div class="notif-tabs" id="notif-filter-tabs">
                            <button type="button" class="notif-tab active" data-filter="all">Todas</button>
                            <button type="button" class="notif-tab" data-filter="unread">No leídas</button>
                            <button type="button" class="notif-tab" data-filter="important">Importantes</button>
                        </div>

                        <div class="notif-history-container">
                            <div class="notif-group">
                                <span class="group-label">Hoy</span>

                                <div class="notif-card unread" data-type="important">
                                    <div class="notif-icon-circle red-bg"><i data-lucide="bell"></i></div>
                                    <div class="notif-details">
                                        <span class="notif-title">Nuevo reporte en tu zona</span>
                                        <span class="notif-message">Se registró una incidencia de alumbrado a 200m de tu ubicación.</span>
                                        <span class="notif-time">Hace 10 min</span>
                                    </div>
                                    <span class="unread-dot"></span>
                                </div>

                                <div class="notif-card unread" data-type="standard">
                                    <div class="notif-icon-circle orange-bg"><i data-lucide="construction"></i></div>
                                    <div class="notif-details">
                                        <span class="notif-title">Reporte en revisión</span>
                                        <span class="notif-message">El reporte #RPT-2024-000120 está siendo evaluado por el Municipio.</span>
                                        <span class="notif-time">Hace 1 hora</span>
                                    </div>
                                    <span class="unread-dot"></span>
                                </div>

                                <div class="notif-card read" data-type="standard">
                                    <div class="notif-icon-circle green-bg"><i data-lucide="check"></i></div>
                                    <div class="notif-details">
                                        <span class="notif-title">Reporte solucionado</span>
                                        <span class="notif-message">El problema denunciado en calle Artigas ha sido resuelto.</span>
                                        <span class="notif-time">Hace 2 horas</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="load-all-wrapper">
                            <button type="button" class="btn-outline-primary" id="btn-mark-all-read">Marcar todas como leídas</button>
                        </div>
                    </div>

                    <!-- 3. MIS REPORTES -->
                    <div class="settings-body tab-content" id="tab-mis-reportes">
                        <div class="notifications-header">
                            <h3>Mis reportes</h3>
                            <p class="section-desc">Gestioná los reportes que realizaste y revisá las alertas de seguimiento.</p>
                        </div>

                        <div class="toggle-card">
                            <div class="toggle-info">
                                <span class="toggle-title">Notificaciones de seguimiento</span>
                                <span class="toggle-desc">Recibirás actualizaciones de estado inmediatamente sobre tus publicaciones.</span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-report-notifs" checked>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="notif-tabs" id="report-filter-tabs">
                            <button type="button" class="notif-tab active" data-report-filter="all">Todos</button>
                            <button type="button" class="notif-tab" data-report-filter="pending">En proceso</button>
                            <button type="button" class="notif-tab" data-report-filter="solved">Solucionados</button>
                        </div>

                        <div class="notif-history-container" id="reports-list">
                            <div class="notif-group">
                                <span class="group-label">Recientes</span>

                                <div class="notif-card unread" data-status="pending">
                                    <div class="notif-icon-circle orange-bg"><i data-lucide="clock"></i></div>
                                    <div class="notif-details">
                                        <span class="notif-title">#RPT-2024-000120 - Reparación de bache</span>
                                        <span class="notif-message">Estado actual: <strong>En revisión por el Municipio</strong>.</span>
                                        <span class="notif-time">Actualizado hace 1 hora</span>
                                    </div>
                                    <span class="unread-dot"></span>
                                </div>

                                <div class="notif-card read" data-status="solved">
                                    <div class="notif-icon-circle green-bg"><i data-lucide="check-circle-2"></i></div>
                                    <div class="notif-details">
                                        <span class="notif-title">#RPT-2024-000115 - Foco sin luz</span>
                                        <span class="notif-message">Estado actual: <strong>Solucionado</strong>.</span>
                                        <span class="notif-time">Resuelto hace 3 días</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="load-all-wrapper">
                            <a href="reportar.php" class="btn-outline-primary block-link">Crear nuevo reporte</a>
                        </div>
                    </div>

                    <!-- 4. PRIVACIDAD -->
                    <div class="settings-body tab-content" id="tab-privacidad">
                        <div class="notifications-header">
                            <h3>Privacidad</h3>
                            <p class="section-desc">Controlá tu visibilidad y cómo se utiliza tu información personal.</p>
                        </div>

                        <div class="privacy-select-card">
                            <div class="privacy-item-left">
                                <div class="privacy-icon"><i data-lucide="eye"></i></div>
                                <div>
                                    <span class="privacy-item-title">Perfil visible para otros vecinos</span>
                                    <span class="privacy-item-desc">Definí cómo ven tu perfil en la comunidad.</span>
                                </div>
                            </div>
                            <select class="privacy-select" id="perfil-visibilidad">
                                <option value="nombre-foto" selected>Nombre y foto</option>
                                <option value="solo-nombre">Solo nombre</option>
                                <option value="anonimo">Anónimo</option>
                            </select>
                        </div>

                        <span class="privacy-section-subtitle">Opciones de interacción</span>
                        
                        <div class="privacy-options-list">
                            <div class="privacy-option-item">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon"><i data-lucide="map-pin"></i></div>
                                    <div>
                                        <span class="privacy-item-title">Mostrar mi ubicación aproximada</span>
                                        <span class="privacy-item-desc">Ubicación general en el mapa comunitario para los reportes.</span>
                                    </div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="toggle-map-profile">
                                    <span class="slider round"></span>
                                </label>
                            </div>

                            <div class="privacy-option-item">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon"><i data-lucide="message-square"></i></div>
                                    <div>
                                        <span class="privacy-item-title">Mensajes privados</span>
                                        <span class="privacy-item-desc">Permitir que vecinos te envíen mensajes de consulta.</span>
                                    </div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="toggle-allow-messages" checked>
                                    <span class="slider round"></span>
                                </label>
                            </div>

                            <div class="privacy-option-item">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon"><i data-lucide="globe"></i></div>
                                    <div>
                                        <span class="privacy-item-title">Reportes públicos</span>
                                        <span class="privacy-item-desc">Tus reportes serán visibles en el mapa general.</span>
                                    </div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" id="toggle-public-reports" checked>
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </div>

                        <span class="privacy-section-subtitle">Gestión de datos</span>

                        <div class="privacy-actions-list">
                            <button type="button" class="privacy-action-item" id="btn-download-data">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon"><i data-lucide="download"></i></div>
                                    <div>
                                        <span class="privacy-item-title">Descargar mis datos</span>
                                        <span class="privacy-item-desc">Obtener una copia en ZIP de tu historial.</span>
                                    </div>
                                </div>
                                <i data-lucide="chevron-right" class="chevron-icon"></i>
                            </button>

                            <button type="button" class="privacy-action-item" id="btn-delete-account">
                                <div class="privacy-item-left">
                                    <div class="privacy-icon" style="color: #ef4444;"><i data-lucide="trash-2"></i></div>
                                    <div>
                                        <span class="privacy-item-title" style="color: #ef4444;">Eliminar mi cuenta</span>
                                        <span class="privacy-item-desc">Borrar de forma permanente tu perfil y publicaciones.</span>
                                    </div>
                                </div>
                                <i data-lucide="chevron-right" class="chevron-icon"></i>
                            </button>
                        </div>
                    </div>

                    <!-- 5. SEGURIDAD -->
                    <div class="settings-body tab-content" id="tab-seguridad">
                        <div class="notifications-header">
                            <h3>Seguridad</h3>
                            <p class="section-desc">Protegé tu cuenta y controlá los accesos a la plataforma.</p>
                        </div>

                        <div class="sec-card-box">
                            <div class="sec-card-left">
                                <div class="sec-card-icon"><i data-lucide="key-round"></i></div>
                                <div class="sec-card-text">
                                    <span class="sec-card-title">Contraseña de acceso</span>
                                    <span class="sec-card-desc">Última modificación hace 3 meses.</span>
                                </div>
                            </div>
                            <button type="button" class="btn-sec-action btn-white" id="btn-change-pass">Cambiar</button>
                        </div>

                        <div class="sec-card-box">
                            <div class="sec-card-left">
                                <div class="sec-card-icon"><i data-lucide="shield-check"></i></div>
                                <div class="sec-card-text">
                                    <span class="sec-card-title">Verificación en dos pasos (2FA)</span>
                                    <span class="sec-card-desc">Capa extra de protección vía SMS o Mail.</span>
                                </div>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-2fa" checked>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="sec-card-box col-layout">
                            <div class="sec-card-row">
                                <div class="sec-card-header">
                                    <div class="sec-card-icon"><i data-lucide="laptop"></i></div>
                                    <div class="sec-card-text">
                                        <span class="sec-card-title">Sesiones activas</span>
                                        <span class="sec-card-desc">Dispositivos conectados actualmente.</span>
                                    </div>
                                </div>
                            </div>

                            <div class="sec-device-list">
                                <div class="sec-device-item">
                                    <div class="sec-device-left">
                                        <i data-lucide="monitor" class="device-icon"></i>
                                        <div class="sec-device-info">
                                            <span class="sec-device-title">Chrome - Windows 11</span>
                                            <span class="sec-device-sub">Guichón, Uruguay • Activo ahora</span>
                                        </div>
                                    </div>
                                    <span class="badge-this-device">Este dispositivo</span>
                                </div>

                                <div class="sec-device-item">
                                    <div class="sec-device-left">
                                        <i data-lucide="smartphone" class="device-icon"></i>
                                        <div class="sec-device-info">
                                            <span class="sec-device-title">NexoGÜI App - Android</span>
                                            <span class="sec-device-sub">Guichón, Uruguay • Hace 2 horas</span>
                                        </div>
                                    </div>
                                    <button type="button" class="btn-danger-outline">Cerrar</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 6. IDIOMA -->
                    <div class="settings-body tab-content" id="tab-idioma">
                        <div class="notifications-header">
                            <h3>Idioma y Región</h3>
                            <p class="section-desc">Ajustá las preferencias de idioma del sistema.</p>
                        </div>
                        <div class="form-group">
                            <label for="idioma-select">Idioma predeterminado</label>
                            <select id="idioma-select" class="privacy-select" style="width: 100%; padding: 12px;">
                                <option value="es" selected>Español (Uruguay)</option>
                                <option value="en">English</option>
                                <option value="pt">Português</option>
                            </select>
                        </div>
                    </div>

                    <!-- 7. APARIENCIA -->
                    <div class="settings-body tab-content" id="tab-apariencia">
                        <div class="notifications-header">
                            <h3>Apariencia</h3>
                            <p class="section-desc">Personalizá el estilo visual de la plataforma según tus preferencias.</p>
                        </div>

                        <div class="theme-selection-grid">
                            <div class="theme-card active" data-theme="light">
                                <div class="theme-preview light-theme-preview">
                                    <div class="preview-header"></div>
                                    <div class="preview-body"></div>
                                </div>
                                <div class="theme-info">
                                    <span class="theme-title">Modo Claro</span>
                                    <span class="theme-desc">Luminoso e idóneo para el día.</span>
                                </div>
                            </div>

                            <div class="theme-card" data-theme="dark">
                                <div class="theme-preview dark-theme-preview">
                                    <div class="preview-header"></div>
                                    <div class="preview-body"></div>
                                </div>
                                <div class="theme-info">
                                    <span class="theme-title">Modo Oscuro</span>
                                    <span class="theme-desc">Descansá tu vista en entornos oscuros.</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 8. ACERCA DE -->
                    <div class="settings-body tab-content" id="tab-acerca-de">
                        <div class="about-container">
                            <div class="about-header">
                                <div class="about-logo">N</div>
                                <h3>Nexo<span>GÜI</span></h3>
                                <span class="version-badge">Versión 1.0.0 (Build 2024)</span>
                            </div>

                            <p class="about-description">
                                Plataforma de gestión vecinal y comunitaria desarrollada para facilitar el reporte de incidencias y la comunicación directa entre los ciudadanos y el Municipio de Guichón.
                            </p>

                            <div class="about-meta-list">
                                <div class="about-meta-item">
                                    <span>Desarrollado para:</span>
                                    <strong>Guichón, Paysandú, Uruguay</strong>
                                </div>
                                <div class="about-meta-item">
                                    <span>Licencia:</span>
                                    <strong>Uso Comunitario Oficial</strong>
                                </div>
                                <div class="about-meta-item">
                                    <span>Soporte:</span>
                                    <a href="mailto:soporte@nexogui.uy">soporte@nexogui.uy</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>

        <!-- COLUMNA DERECHA / MAPA Y CONTACTOS -->
        <div class="content-right">
            
            <div class="map-card">
                <div class="map-header">
                    <i data-lucide="map-pin" class="map-icon"></i>
                    <h3>MAPA DE GUICHÓN</h3>
                </div>
                <div id="map"></div>
            </div>

            <!-- Emergencias -->
            <div class="contact-card emergency">
                <div class="card-icon-round red">
                    <i data-lucide="siren"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Emergencias:</span>
                    <span class="contact-number red-text">911</span>
                </div>
            </div>

            <!-- Municipio -->
            <div class="contact-card municipio">
                <div class="card-icon-round blue">
                    <i data-lucide="landmark"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Municipio:</span>
                    <span class="contact-number blue-text">2200</span>
                </div>
            </div>

        </div>

    </main>

</div>

<!-- Scripts JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    lucide.createIcons();
</script>
<script src="js/ajustes.js"></script>
</body>
</html>