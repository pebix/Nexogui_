document.addEventListener('DOMContentLoaded', () => {

    // 1. MAPA INTERACTIVO (Guichón)
    const guichonCoords = [-32.3486, -57.2000];
    const map = L.map('map').setView(guichonCoords, 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap'
    }).addTo(map);

    // Marcador principal seleccionable
    let activeMarker = L.marker(guichonCoords, { draggable: true }).addTo(map);

    function updateLocationInputs(lat, lng, label = "") {
        document.getElementById('latitud').value = lat;
        document.getElementById('longitud').value = lng;
        if (label) {
            document.getElementById('ubicacion').value = label;
        } else {
            document.getElementById('ubicacion').value = `Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)}`;
        }
    }

    activeMarker.on('dragend', function () {
        const pos = activeMarker.getLatLng();
        updateLocationInputs(pos.lat, pos.lng);
    });

    map.on('click', function(e) {
        activeMarker.setLatLng(e.latlng);
        updateLocationInputs(e.latlng.lat, e.latlng.lng);
    });

    // 2. GEOLOCALIZACIÓN
    const btnGeolocate = document.getElementById('btn-geolocation');
    const btnUseLocation = document.getElementById('btn-use-location');

    function getLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                map.setView([lat, lng], 16);
                activeMarker.setLatLng([lat, lng]);
                updateLocationInputs(lat, lng, "Mi ubicación actual");
            }, () => {
                alert("No se pudo obtener la ubicación. Verifique los permisos de su navegador.");
            });
        } else {
            alert("La geolocalización no está soportada por su navegador.");
        }
    }

    btnGeolocate.addEventListener('click', getLocation);
    btnUseLocation.addEventListener('click', getLocation);

    // 3. SELECCIÓN DE CATEGORÍA
    const categoryButtons = document.querySelectorAll('.cat-card');
    const selectedCategoryInput = document.getElementById('selected-category');

    categoryButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            categoryButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedCategoryInput.value = btn.dataset.cat;
        });
    });

    // 4. CONTADOR DE CARACTERES
    const descTextarea = document.getElementById('descripcion');
    const charCounter = document.getElementById('char-counter');

    descTextarea.addEventListener('input', () => {
        const currentLength = descTextarea.value.length;
        charCounter.textContent = `${currentLength}/500`;
    });

    // 5. CARGA Y PREVISUALIZACIÓN DE FOTOS
    const fotosInput = document.getElementById('fotos-input');
    const previewContainer = document.getElementById('preview-container');
    let selectedFiles = [];

    // Previsualizaciones estáticas iniciales (para emular la interfaz de la imagen)
    const mockImages = [
        "https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=200&q=80",
        "https://images.unsplash.com/photo-1584467735871-8e85353a8413?auto=format&fit=crop&w=200&q=80"
    ];

    function renderMockPreviews() {
        mockImages.forEach(src => {
            const thumb = createThumbElement(src);
            previewContainer.appendChild(thumb);
        });
    }

    function createThumbElement(src) {
        const div = document.createElement('div');
        div.className = 'preview-thumb';
        div.innerHTML = `
            <img src="${src}" alt="Vista previa">
            <button type="button" class="remove-btn"><i data-lucide="x"></i></button>
        `;
        
        div.querySelector('.remove-btn').addEventListener('click', () => {
            div.remove();
        });

        return div;
    }

    fotosInput.addEventListener('change', (e) => {
        const files = Array.from(e.target.files);
        
        files.forEach(file => {
            if (previewContainer.children.length >= 5) {
                alert("Solo podés subir un máximo de 5 fotos.");
                return;
            }

            const reader = new FileReader();
            reader.onload = (event) => {
                const thumb = createThumbElement(event.target.result);
                previewContainer.appendChild(thumb);
                lucide.createIcons();
            };
            reader.readAsDataURL(file);
        });
    });

    renderMockPreviews();
    lucide.createIcons();
});