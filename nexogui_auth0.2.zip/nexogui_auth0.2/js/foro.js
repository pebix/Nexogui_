document.addEventListener("DOMContentLoaded", () => {
    // 1. Inicializar Mapa de Guichón
    const guichonCoords = [-32.3484, -57.2000];
    const map = L.map('map').setView(guichonCoords, 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // Marcadores de prueba en el mapa
    L.marker([-32.3484, -57.2000]).addTo(map).bindPopup('Centro de Guichón');
    L.marker([-32.3450, -57.1950]).addTo(map).bindPopup('Reporte en Vías');

    // 2. Cambio activo de pestañas de categoría
    const tabButtons = document.querySelectorAll('.category-tabs .tab-item');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
        });
    });

    // 3. Filtro rápido de búsqueda local
    const searchInput = document.getElementById('search-input');
    const topicItems = document.querySelectorAll('.topic-item');

    if (searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            const query = e.target.value.toLowerCase();
            topicItems.forEach(item => {
                const title = item.querySelector('.topic-title').textContent.toLowerCase();
                if (title.includes(query)) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }
});