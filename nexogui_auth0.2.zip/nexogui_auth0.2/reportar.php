<?php
session_start();

// Datos del usuario logueado o valores por defecto
$nombreUsuario = $_SESSION['user_name'] ?? 'Juan Pérez';
$rolUsuario   = $_SESSION['user_role'] ?? 'Vecino';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexoGÜI - Reportar Problema</title>

    <!-- 1. Librerías Externas (CSS e Iconos) -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <!-- 2. Tu Hojal de Estilos CSS (Ubicada en la carpeta css/) -->
    <link rel="stylesheet" href="css/reportar.css">
</head>
<body>

<div class="dashboard-layout">
    
    <!-- BARRA LATERAL (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon"><span>N</span></div>
            <h1 class="logo-text">Nexo<span>GÜI</span></h1>
        </div>

        <nav class="sidebar-nav">
            <a href="inicio.php" class="nav-item">
                <i data-lucide="home"></i> Inicio
            </a>
            <a href="reportar.php" class="nav-item active">
                <i data-lucide="plus-circle"></i> Reportar
            </a>
            <a href="foro.php" class="nav-item">
                <i data-lucide="message-square"></i> Foro
            </a>
            <a href="ajustes.php" class="nav-item">
                <i data-lucide="settings"></i> Ajustes
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="avatar">
                    <i data-lucide="user"></i>
                </div>
                <div class="user-info">
                    <span class="user-name"><?php echo htmlspecialchars($nombreUsuario); ?></span>
                    <span class="user-role"><?php echo htmlspecialchars($rolUsuario); ?></span>
                </div>
                <i data-lucide="chevron-down" class="dropdown-icon"></i>
            </div>
        </div>
    </aside>

    <!-- CONTENIDO PRINCIPAL -->
    <main class="main-content">
        
        <!-- COLUMNA IZQUIERDA / FORMULARIO -->
        <div class="content-left">
            
            <div class="page-header">
                <a href="inicio.php" class="back-btn" title="Volver al inicio">
                    <i data-lucide="arrow-left"></i>
                </a>
                <div class="header-title-group">
                    <div class="header-title">
                        <i data-lucide="file-plus" class="header-icon"></i>
                        <h2>REPORTAR</h2>
                    </div>
                    <p class="header-subtitle">Reportá un problema en tu ciudad y ayudanos a mejorar Guichón.</p>
                </div>
            </div>

            <form action="process_report.php" method="POST" enctype="multipart/form-data" class="report-card-form" id="main-report-form">
                
                <!-- 1. CATEGORÍA -->
                <div class="form-block">
                    <label class="block-title">1. Seleccioná una categoría</label>
                    <div class="category-grid">
                        <button type="button" class="cat-card active" data-cat="Vías">
                            <i data-lucide="milestone"></i> Vías
                        </button>
                        <button type="button" class="cat-card" data-cat="Alumbrado">
                            <i data-lucide="lightbulb"></i> Alumbrado
                        </button>
                        <button type="button" class="cat-card" data-cat="Parques">
                            <i data-lucide="trees"></i> Parques
                        </button>
                        <button type="button" class="cat-card" data-cat="Agua">
                            <i data-lucide="droplet"></i> Agua
                        </button>
                        <button type="button" class="cat-card" data-cat="Otro">
                            <i data-lucide="more-horizontal"></i> Otro
                        </button>
                    </div>
                    <input type="hidden" name="categoria" id="selected-category" value="Vías">
                </div>

                <!-- 2. UBICACIÓN -->
                <div class="form-block">
                    <label class="block-title" for="ubicacion">2. Ubicación del problema</label>
                    <div class="input-with-actions">
                        <i data-lucide="map-pin" class="input-left-icon"></i>
                        <input type="text" id="ubicacion" name="ubicacion" placeholder="Buscar dirección o seleccionar en el mapa..." required>
                        <button type="button" class="locate-btn" id="btn-geolocation" title="Usar mi ubicación">
                            <i data-lucide="crosshair"></i>
                        </button>
                    </div>
                    <button type="button" class="link-action-btn" id="btn-use-location">
                        <i data-lucide="navigation"></i> Usar mi ubicación actual
                    </button>
                    <input type="hidden" id="latitud" name="latitud">
                    <input type="hidden" id="longitud" name="longitud">
                </div>

                <!-- 3. DESCRIPCIÓN -->
                <div class="form-block">
                    <label class="block-title" for="descripcion">3. Descripción del problema</label>
                    <div class="textarea-wrapper">
                        <textarea id="descripcion" name="descripcion" maxlength="500" rows="4" placeholder="Contanos qué está pasando, sé lo más detallado posible..." required></textarea>
                        <span class="char-counter" id="char-counter">0/500</span>
                    </div>
                </div>

                <!-- 4. FOTOS -->
                <div class="form-block">
                    <label class="block-title">4. Agregá fotos <span class="optional">(opcional)</span></label>
                    
                    <div class="upload-and-previews">
                        <label class="dropzone" for="fotos-input">
                            <i data-lucide="camera" class="camera-icon"></i>
                            <span class="dropzone-title">Subir fotos</span>
                            <span class="dropzone-subtitle">Arrastrá o seleccioná archivos</span>
                            <span class="dropzone-formats">Formatos: JPG, PNG - Máx. 5MB c/u</span>
                            <input type="file" name="fotos[]" id="fotos-input" accept="image/png, image/jpeg" multiple hidden>
                        </label>

                        <!-- Las imágenes de vista previa se renderizan aquí mediante js/reportar.js -->
                        <div class="image-previews" id="preview-container"></div>
                    </div>
                    <span class="max-photos-info">Máx. 5 fotos</span>
                </div>

                <!-- ACCIONES DEL FORMULARIO -->
                <div class="form-footer-actions">
                    <a href="inicio.php" class="btn btn-cancel">
                        <i data-lucide="x"></i> Cancelar
                    </a>
                    <button type="submit" class="btn btn-submit">
                        <i data-lucide="send"></i> ENVIAR REPORTE
                    </button>
                </div>

            </form>

        </div>

        <!-- COLUMNA DERECHA / MAPA Y EMERGENCIAS -->
        <div class="content-right">
            
            <div class="map-card">
                <div class="map-header">
                    <i data-lucide="map-pin" class="map-icon"></i>
                    <h3>MAPA DE GUICHÓN</h3>
                </div>
                <div id="map"></div>
            </div>

            <!-- Emergencias -->
            <div class="contact-card emergency">
                <div class="card-icon-round red">
                    <i data-lucide="siren"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Emergencias:</span>
                    <span class="contact-number red-text">911</span>
                </div>
            </div>

            <!-- Municipio -->
            <div class="contact-card municipio">
                <div class="card-icon-round blue">
                    <i data-lucide="landmark"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Municipio:</span>
                    <span class="contact-number blue-text">2200</span>
                </div>
            </div>

        </div>

    </main>

</div>

<!-- Scripts JavaScript (Al final del body para no ralentizar el renderizado) -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    lucide.createIcons();
</script>
<script src="js/reportar.js"></script>
</body>
</html>