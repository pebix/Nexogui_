document.addEventListener('DOMContentLoaded', () => {
    let map = null;

    // ==========================================
    // 1. NAVEGACIÓN Y CAMBIO DE PESTAÑAS
    // ==========================================
    const navItems = document.querySelectorAll('.settings-nav-item[data-tab]');
    const tabContents = document.querySelectorAll('.tab-content');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const targetTab = item.getAttribute('data-tab');

            // Desactivar todos los botones y ocultar vistas
            navItems.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Activar botón seleccionado
            item.classList.add('active');

            // Mostrar el contenedor correspondiente
            const targetContent = document.getElementById(`tab-${targetTab}`);
            if (targetContent) {
                targetContent.classList.add('active');
            }

            // Volver a renderizar los íconos de Lucide
            if (window.lucide) {
                lucide.createIcons();
            }

            // Si el mapa existe y la pestaña de ubicación se vuelve visible, forzar el recalculado del tamaño
            if (map && targetTab === 'ubicacion') {
                setTimeout(() => {
                    map.invalidateSize();
                }, 100);
            }
        });
    });

    // ==========================================
    // 2. INICIALIZAR MAPA DE GUICHÓN
    // ==========================================
    const mapElement = document.getElementById('map');
    if (mapElement && typeof L !== 'undefined') {
        const guichonCoords = [-32.3484, -57.2000];
        map = L.map('map').setView(guichonCoords, 14);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        L.marker(guichonCoords).addTo(map).bindPopup('Guichón');
    }

    // ==========================================
    // 3. PREVISUALIZACIÓN DE AVATAR
    // ==========================================
    const avatarInput = document.getElementById('avatar-input');
    if (avatarInput) {
        avatarInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    const avatarBox = document.querySelector('.profile-avatar');
                    if (avatarBox) {
                        avatarBox.innerHTML = `<img src="${event.target.result}" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">`;
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // ==========================================
    // 4. ACCIONES Y ACCESOS DIRECTOS
    // ==========================================
    const btnVerTodos = document.getElementById('btn-ver-todos-reportes');
    if (btnVerTodos) {
        btnVerTodos.addEventListener('click', () => {
            window.location.href = 'reportar.php';
        });
    }

    const btnDescargarDatos = document.getElementById('btn-descargar-datos');
    if (btnDescargarDatos) {
        btnDescargarDatos.addEventListener('click', () => {
            alert('Descargando copia de tus datos...');
        });
    }

    const btnEliminarCuenta = document.getElementById('btn-eliminar-cuenta');
    if (btnEliminarCuenta) {
        btnEliminarCuenta.addEventListener('click', () => {
            if (confirm('¿Estás seguro de que querés eliminar tu cuenta de forma permanente?')) {
                window.location.href = 'logout.php';
            }
        });
    }

   