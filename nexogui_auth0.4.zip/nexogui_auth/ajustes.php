<?php
session_start();

// Datos del usuario desde la sesión
$nombreUsuario = $_SESSION['user_name'] ?? 'Juan Pérez';
$rolUsuario   = $_SESSION['user_role'] ?? 'Vecino';
$emailUsuario = $_SESSION['user_email'] ?? 'juan.perez@email.com';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexoGÜI - Ajustes</title>

    <!-- Librerías Externas -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <!-- CSS de Ajustes -->
    <link rel="stylesheet" href="css/ajustes.css">
</head>
<body>

<div class="dashboard-layout">
    
    <!-- BARRA LATERAL (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon"><span>N</span></div>
            <h1 class="logo-text">Nexo<span>GÜI</span></h1>
        </div>

        <nav class="sidebar-nav">
            <a href="inicio.php" class="nav-item">
                <i data-lucide="home"></i> Inicio
            </a>
            <a href="reportar.php" class="nav-item">
                <i data-lucide="plus-circle"></i> Reportar
            </a>
            <a href="foro.php" class="nav-item">
                <i data-lucide="message-square"></i> Foro
            </a>
            <a href="ajustes.php" class="nav-item active">
                <i data-lucide="settings"></i> Ajustes
            </a>
        </nav>

        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="avatar">
                    <i data-lucide="user"></i>
                </div>
                <div class="user-info">
                    <span class="user-name"><?php echo htmlspecialchars($nombreUsuario); ?></span>
                    <span class="user-role"><?php echo htmlspecialchars($rolUsuario); ?></span>
                </div>
                <i data-lucide="chevron-down" class="dropdown-icon"></i>
            </div>
        </div>
    </aside>

    <!-- CONTENIDO PRINCIPAL -->
    <main class="main-content">
        
        <!-- COLUMNA IZQUIERDA / PANEL DE AJUSTES -->
        <div class="content-left">
            
            <!-- Encabezado de la página -->
            <div class="settings-header">
                <div class="title-with-icon">
                    <i data-lucide="settings" class="settings-icon"></i>
                    <h2>AJUSTES</h2>
                </div>
                <p>Personalizá tu experiencia y gestioná tu cuenta.</p>
            </div>

            <!-- Tarjeta Contenedora de Ajustes -->
            <div class="settings-card">
                
                <!-- Menú Lateral Interno de Ajustes -->
                <div class="settings-sidebar">
                    <button class="settings-nav-item active" data-tab="mi-cuenta">
                        <i data-lucide="user"></i>
                        <div>
                            <span class="nav-title">Mi cuenta</span>
                            <span class="nav-sub">Información personal</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="notificaciones">
                        <i data-lucide="bell"></i>
                        <div>
                            <span class="nav-title">Notificaciones</span>
                            <span class="nav-sub">Preferencias y alertas</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="mis-reportes">
                        <i data-lucide="file-text"></i>
                        <div>
                            <span class="nav-title">Mis reportes</span>
                            <span class="nav-sub">Historial y seguimiento</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="privacidad">
                        <i data-lucide="shield"></i>
                        <div>
                            <span class="nav-title">Privacidad</span>
                            <span class="nav-sub">Seguridad y datos</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="seguridad">
                        <i data-lucide="lock"></i>
                        <div>
                            <span class="nav-title">Seguridad</span>
                            <span class="nav-sub">Contraseña y verificación</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="idioma">
                        <i data-lucide="globe"></i>
                        <div>
                            <span class="nav-title">Idioma</span>
                            <span class="nav-sub">Idioma de la aplicación</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="apariencia">
                        <i data-lucide="palette"></i>
                        <div>
                            <span class="nav-title">Apariencia</span>
                            <span class="nav-sub">Tema y visualización</span>
                        </div>
                    </button>

                    <button class="settings-nav-item" data-tab="acerca-de">
                        <i data-lucide="info"></i>
                        <div>
                            <span class="nav-title">Acerca de</span>
                            <span class="nav-sub">Info de la aplicación</span>
                        </div>
                    </button>

                    <a href="logout.php" class="settings-nav-item logout-link">
                        <i data-lucide="log-out"></i>
                        <div>
                            <span class="nav-title">Cerrar sesión</span>
                            <span class="nav-sub">Salir de tu cuenta</span>
                        </div>
                    </a>
                </div>

                <!-- CONTENIDOS DE LAS PESTAÑAS -->
                
                <!-- 1. MI CUENTA (ACTIVA POR DEFECTO) -->
                <div class="settings-body tab-content active" id="tab-mi-cuenta">
                    <form action="process_settings.php" method="POST" enctype="multipart/form-data">
                        <div class="body-header">
                            <h3>Información de la cuenta</h3>
                            <div class="avatar-upload-wrapper">
                                <div class="profile-avatar">
                                    <i data-lucide="user"></i>
                                </div>
                                <label for="avatar-input" class="camera-btn" title="Cambiar foto">
                                    <i data-lucide="camera"></i>
                                    <input type="file" id="avatar-input" name="avatar" accept="image/*" hidden>
                                </label>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="nombre">Nombre completo</label>
                            <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombreUsuario); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Correo electrónico</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($emailUsuario); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="telefono">Teléfono <span class="optional">(opcional)</span></label>
                            <input type="tel" id="telefono" name="telefono" value="098 765 432">
                        </div>

                        <div class="form-group">
                            <label for="direccion">Dirección</label>
                            <input type="text" id="direccion" name="direccion" value="Guichón, Paysandú, Uruguay">
                        </div>

                        <div class="form-group">
                            <label for="biografia">Biografía <span class="optional">(opcional)</span></label>
                            <textarea id="biografia" name="biografia" rows="4">Vecino comprometido con la comunidad.</textarea>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-save">
                                <i data-lucide="save"></i> GUARDAR CAMBIOS
                            </button>
                        </div>
                    </form>
                </div>

                <!-- 2. NOTIFICACIONES -->
                <div class="settings-body tab-content" id="tab-notificaciones">
                    <div class="notifications-header">
                        <h3>Notificaciones</h3>
                        <p class="section-desc">Elegí cómo y cuándo querés recibir notificaciones.</p>
                    </div>

                    <div class="toggle-card">
                        <div class="toggle-info">
                            <span class="toggle-title">Notificaciones activadas</span>
                            <span class="toggle-desc">Recibirás alertas sobre reportes, comentarios y actualizaciones importantes.</span>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="toggle-notifications" checked>
                            <span class="slider round"></span>
                        </label>
                    </div>

                    <div class="notif-tabs">
                        <button class="notif-tab active">Todas</button>
                    </div>

                    <div class="notif-group">
                        <span class="group-label">Hoy</span>

                        <div class="notif-card">
                            <div class="notif-icon-circle red-bg"><i data-lucide="bell"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Nuevo reporte recibido</span>
                                <span class="notif-message">Se ha recibido un nuevo reporte en tu zona.</span>
                                <span class="notif-time">Hace 10 min</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle orange-bg"><i data-lucide="construction"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Reporte en revisión</span>
                                <span class="notif-message">El reporte #RPT-2024-000120 está siendo revisado.</span>
                                <span class="notif-time">Hace 1 hora</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle green-bg"><i data-lucide="check"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Reporte solucionado</span>
                                <span class="notif-message">El reporte #RPT-2024-000115 fue solucionado.</span>
                                <span class="notif-time">Hace 2 horas</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle blue-bg"><i data-lucide="info"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Nuevo comentario</span>
                                <span class="notif-message">Vecino123 comentó en el reporte #RPT-2024-000110.</span>
                                <span class="notif-time">Ayer, 18:30</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>
                    </div>

                    <div class="notif-group">
                        <span class="group-label">Ayer</span>
                        <div class="notif-card">
                            <div class="notif-icon-circle blue-bg"><i data-lucide="info"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Actualización de estado</span>
                                <span class="notif-message">El reporte #RPT-2024-000108 cambió de estado.</span>
                                <span class="notif-time">Ayer, 15:45</span>
                            </div>
                        </div>
                    </div>

                    <div class="load-all-wrapper">
                        <button class="btn-outline-primary">Ver todas las notificaciones</button>
                    </div>
                </div>

                <!-- 3. MIS REPORTES -->
                <div class="settings-body tab-content" id="tab-mis-reportes">
                    <div class="notifications-header">
                        <h3>Mis reportes</h3>
                        <p class="section-desc">Administrá cómo recibís notificaciones sobre tus reportes.</p>
                    </div>

                    <div class="toggle-card">
                        <div class="toggle-info">
                            <span class="toggle-title">Notificaciones de mis reportes</span>
                            <span class="toggle-desc">Recibirás actualizaciones sobre el estado y seguimiento de tus reportes.</span>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="toggle-report-notifs" checked>
                            <span class="slider round"></span>
                        </label>
                    </div>

                    <div class="notif-tabs">
                        <button class="notif-tab active">Todas</button>
                    </div>

                    <div class="notif-group">
                        <span class="group-label">Hoy</span>

                        <div class="notif-card">
                            <div class="notif-icon-circle blue-bg"><i data-lucide="send"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Reporte #RPT-2024-000123 actualizado</span>
                                <span class="notif-message">Tu reporte fue revisado por el equipo.</span>
                                <span class="notif-time">Hace 30 min</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle orange-bg"><i data-lucide="clock"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Cambio de estado en reporte #RPT-2024-000120</span>
                                <span class="notif-message">El estado cambió a "En revisión".</span>
                                <span class="notif-time">Hace 1 hora</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle green-bg"><i data-lucide="check-circle-2"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Reporte #RPT-2024-000115 solucionado</span>
                                <span class="notif-message">Tu reporte fue solucionado exitosamente.</span>
                                <span class="notif-time">Hace 3 horas</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle slate-bg"><i data-lucide="message-square"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Nuevo comentario en reporte #RPT-2024-000110</span>
                                <span class="notif-message">Vecino123 comentó en tu reporte.</span>
                                <span class="notif-time">Ayer, 18:30</span>
                            </div>
                            <span class="unread-dot"></span>
                        </div>
                    </div>

                    <div class="notif-group">
                        <span class="group-label">Ayer</span>

                        <div class="notif-card">
                            <div class="notif-icon-circle info-bg"><i data-lucide="info"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Reporte #RPT-2024-000108 creado</span>
                                <span class="notif-message">Tu reporte fue recibido correctamente.</span>
                                <span class="notif-time">Ayer, 15:45</span>
                            </div>
                        </div>
                    </div>

                    <div class="load-all-wrapper">
                        <button class="btn-outline-primary" id="btn-ver-todos-reportes">Ver todos mis reportes</button>
                    </div>
                </div>

                <!-- 4. PRIVACIDAD -->
                <div class="settings-body tab-content" id="tab-privacidad">
                    <div class="notifications-header">
                        <h3>Privacidad</h3>
                        <p class="section-desc">Controlá tu privacidad y cómo se usa tu información.</p>
                    </div>

                    <div class="toggle-card">
                        <div class="toggle-info">
                            <span class="toggle-title">Perfil visible para otros vecinos</span>
                            <span class="toggle-desc">Controlá qué información de tu perfil puede ver el resto de la comunidad.</span>
                        </div>
                        <select class="settings-select" id="perfil-visibilidad" style="padding: 8px 12px; border-radius: 6px; border: 1px solid #cbd5e1; background: #fff;">
                            <option value="nombre-foto" selected>Nombre y foto</option>
                            <option value="solo-nombre">Solo nombre</option>
                            <option value="anonimo">Anónimo</option>
                        </select>
                    </div>

                    <div class="notif-group">
                        <span class="group-label">Opciones de privacidad</span>

                        <div class="notif-card">
                            <div class="notif-icon-circle blue-bg"><i data-lucide="user"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Mostrar mi perfil en el mapa</span>
                                <span class="notif-message">Tu ubicación aproximada se mostrará en el mapa para otros vecinos.</span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-map-profile">
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle green-bg"><i data-lucide="message-square"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Permitir mensajes de otros vecinos</span>
                                <span class="notif-message">Otros vecinos podrán enviarte mensajes privados.</span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-allow-messages" checked>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle orange-bg"><i data-lucide="bell"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Mostrar mis reportes públicamente</span>
                                <span class="notif-message">Los reportes que crees serán visibles para la comunidad.</span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-public-reports" checked>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle slate-bg"><i data-lucide="user-plus"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Permitir que me sigan</span>
                                <span class="notif-message">Otros vecinos podrán seguir tus reportes y actividad.</span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-allow-follow">
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>

                    <div class="notif-group">
                        <span class="group-label">Datos y permisos</span>

                        <div class="notif-card">
                            <div class="notif-icon-circle blue-bg"><i data-lucide="shield"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Descargar mis datos</span>
                                <span class="notif-message">Obtené una copia de la información asociada a tu cuenta.</span>
                            </div>
                            <button type="button" class="btn-outline-primary" style="padding: 6px 12px; font-size: 0.85rem;">Solicitar</button>
                        </div>

                        <div class="notif-card">
                            <div class="notif-icon-circle red-bg"><i data-lucide="trash-2"></i></div>
                            <div class="notif-details">
                                <span class="notif-title">Eliminar mi cuenta</span>
                                <span class="notif-message">Eliminá tu cuenta y todos tus datos de forma permanente.</span>
                            </div>
                            <button type="button" class="btn-outline-primary" style="padding: 6px 12px; font-size: 0.85rem; color: #ef4444; border-color: #ef4444;">Eliminar</button>
                        </div>
                    </div>
                </div>

                <!-- 5. SEGURIDAD -->
                <div class="settings-body tab-content" id="tab-seguridad">
                    
                    <div class="notifications-header">
                        <h3>Seguridad</h3>
                        <p class="section-desc">Mantené tu cuenta protegida y controlá cómo accedés a ella.</p>
                    </div>

                    <div class="notif-group">
                        <!-- Contraseña -->
                        <div class="notif-card">
                            <div class="notif-icon-circle blue-bg">
                                <i data-lucide="lock"></i>
                            </div>
                            <div class="notif-details">
                                <span class="notif-title">Contraseña</span>
                                <span class="notif-message">Usá una contraseña segura para proteger tu cuenta.</span>
                            </div>
                            <button type="button" class="btn-outline-primary" style="width: auto; padding: 6px 14px; font-size: 0.85rem;">Cambiar contraseña</button>
                        </div>

                        <!-- Verificación en dos pasos -->
                        <div class="notif-card">
                            <div class="notif-icon-circle green-bg">
                                <i data-lucide="shield"></i>
                            </div>
                            <div class="notif-details">
                                <span class="notif-title">Verificación en dos pasos</span>
                                <span class="notif-message">Agregá una capa extra de seguridad a tu cuenta.</span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="toggle-2fa" checked>
                                <span class="slider round"></span>
                            </label>
                        </div>

                        <!-- Banner 2FA Activo -->
                        <div class="notif-card" style="background-color: #eff6ff; border-color: #bfdbfe;">
                            <div class="notif-icon-circle blue-bg">
                                <i data-lucide="info"></i>
                            </div>
                            <div class="notif-details">
                                <span class="notif-title" style="color: #1d4ed8;">La verificación en dos pasos está activada.</span>
                                <span class="notif-message" style="color: #2563eb;">Usamos tu teléfono para enviarte códigos de verificación.</span>
                            </div>
                            <button type="button" class="btn-outline-primary" style="width: auto; padding: 6px 14px; font-size: 0.85rem; background: #fff;">Gestionar</button>
                        </div>
                    </div>

                    <!-- Sesiones activas -->
                    <div class="notif-group" style="margin-top: 24px;">
                        <span class="group-label">Sesiones activas</span>
                        <p class="section-desc" style="margin-top: -4px; margin-bottom: 12px; font-size: 0.85rem;">Gestioná los dispositivos donde iniciaste sesión.</p>

                        <!-- Dispositivo 1 -->
                        <div class="notif-card">
                            <div class="notif-icon-circle slate-bg">
                                <i data-lucide="monitor"></i>
                            </div>
                            <div class="notif-details">
                                <span class="notif-title">Navegador Chrome - Windows</span>
                                <span class="notif-message">Guichón, Paysandú, Uruguay • Actualmente</span>
                            </div>
                            <span style="background-color: #dcfce7; color: #15803d; font-size: 0.75rem; font-weight: 700; padding: 4px 10px; border-radius: 6px; white-space: nowrap;">Este dispositivo</span>
                        </div>

                        <!-- Dispositivo 2 -->
                        <div class="notif-card">
                            <div class="notif-icon-circle orange-bg">
                                <i data-lucide="smartphone"></i>
                            </div>
                            <div class="notif-details">
                                <span class="notif-title">Navegador Safari - iPhone</span>
                                <span class="notif-message">Guichón, Paysandú, Uruguay • Hace 2 días</span>
                            </div>
                            <button type="button" class="btn-outline-primary" style="width: auto; padding: 6px 12px; font-size: 0.85rem; color: #ef4444; border-color: #ef4444;">Cerrar sesión</button>
                        </div>

                        <!-- Ver todas las sesiones -->
                        <div style="margin-top: 10px;">
                            <a href="#" style="color: #2563eb; font-weight: 600; text-decoration: none; font-size: 0.85rem; display: inline-flex; align-items: center; gap: 4px;">
                                Ver todas las sesiones <i data-lucide="chevron-right" style="width: 16px; height: 16px;"></i>
                            </a>
                        </div>
                    </div>

                    <!-- Actividad reciente -->
                    <div class="notif-card" style="margin-top: 20px; cursor: pointer;">
                        <div class="notif-icon-circle slate-bg">
                            <i data-lucide="clock"></i>
                        </div>
                        <div class="notif-details">
                            <span class="notif-title">Actividad reciente</span>
                            <span class="notif-message">Revisá los últimos accesos a tu cuenta.</span>
                        </div>
                        <i data-lucide="chevron-right" style="color: #64748b; width: 18px; height: 18px;"></i>
                    </div>

                    <!-- Consejo de Seguridad -->
                    <div class="notif-card" style="background-color: #f0fdf4; border-color: #bbf7d0; margin-top: 20px;">
                        <div class="notif-icon-circle green-bg">
                            <i data-lucide="check-circle-2"></i>
                        </div>
                        <div class="notif-details">
                            <span class="notif-title" style="color: #166534;">Consejo de seguridad</span>
                            <span class="notif-message" style="color: #15803d; margin-bottom: 4px;">Nunca compartas tu contraseña ni códigos de verificación con otras personas.</span>
                            <a href="#" style="color: #16a34a; font-weight: 700; font-size: 0.85rem; text-decoration: underline;">Más consejos de seguridad</a>
                        </div>
                    </div>

                </div>
               
                

                <!-- 7. APARIENCIA -->
                <div class="settings-body tab-content" id="tab-apariencia">
                    <h3>Apariencia</h3>
                    <p class="section-desc">Personalizá el tema y colores de la pantalla.</p>
                    <p style="color: #64748b; font-size: 0.9rem;">Modo Claro / Modo Oscuro.</p>
                </div>

                <!-- 8. ACERCA DE -->
                <div class="settings-body tab-content" id="tab-acerca-de">
                    <h3>Acerca de</h3>
                    <p class="section-desc">Información sobre NexoGÜI.</p>
                    <p style="color: #64748b; font-size: 0.9rem;">Versión 1.0.0 - Desarrollado para Guichón.</p>
                </div>

            </div>

        </div>

        <!-- COLUMNA DERECHA / MAPA Y CONTACTOS -->
        <div class="content-right">
            
            <div class="map-card">
                <div class="map-header">
                    <i data-lucide="map-pin" class="map-icon"></i>
                    <h3>MAPA DE GUICHÓN</h3>
                </div>
                <div id="map"></div>
            </div>

            <!-- Emergencias -->
            <div class="contact-card emergency">
                <div class="card-icon-round red">
                    <i data-lucide="siren"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Emergencias:</span>
                    <span class="contact-number red-text">911</span>
                </div>
            </div>

            <!-- Municipio -->
            <div class="contact-card municipio">
                <div class="card-icon-round blue">
                    <i data-lucide="landmark"></i>
                </div>
                <div class="contact-info">
                    <span class="contact-label">Municipio:</span>
                    <span class="contact-number blue-text">2200</span>
                </div>
            </div>

        </div>

    </main>

</div>

<!-- Scripts JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    lucide.createIcons();
</script>
<script src="js/ajustes.js"></script>
</body>
</html>